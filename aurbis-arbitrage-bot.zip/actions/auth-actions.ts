"use server"

import { createServerSupabaseClient } from "@/lib/supabase/server"
import { generateVerificationCode } from "@/lib/email-service"

export async function signUpUser(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const username = formData.get("username") as string

  if (!email || !password || !username) {
    return { success: false, error: "Missing required fields" }
  }

  const supabase = createServerSupabaseClient()

  try {
    // Generate and send verification code
    const { success, error: codeError } = await generateVerificationCode(email)

    if (!success) {
      return { success: false, error: codeError || "Failed to generate verification code" }
    }

    // Create the user
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username,
        },
      },
    })

    if (error) {
      return { success: false, error: error.message }
    }

    return { success: true, email }
  } catch (error) {
    console.error("Sign up error:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function verifyEmailWithCode(formData: FormData) {
  const email = formData.get("email") as string
  const code = formData.get("code") as string

  if (!email || !code) {
    return { success: false, error: "Missing required fields" }
  }

  const supabase = createServerSupabaseClient()

  try {
    // Get the latest verification code for this email
    const { data, error } = await supabase
      .from("verification_codes")
      .select("*")
      .eq("email", email)
      .eq("verified", false)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(1)
      .single()

    if (error || !data) {
      return { success: false, error: "No valid verification code found" }
    }

    // Check if the code matches
    if (data.code !== code) {
      return { success: false, error: "Invalid verification code" }
    }

    // Mark the code as verified
    await supabase.from("verification_codes").update({ verified: true }).eq("id", data.id)

    return { success: true }
  } catch (error) {
    console.error("Verification error:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}

export async function resendVerificationCode(formData: FormData) {
  const email = formData.get("email") as string

  if (!email) {
    return { success: false, error: "Email is required" }
  }

  const { success, error } = await generateVerificationCode(email)

  if (!success) {
    return { success: false, error: error || "Failed to generate verification code" }
  }

  return { success: true }
}

export async function signInUser(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string

  if (!email || !password) {
    return { success: false, error: "Missing required fields" }
  }

  const supabase = createServerSupabaseClient()

  try {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) {
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Sign in error:", error)
    return { success: false, error: "An unexpected error occurred" }
  }
}
