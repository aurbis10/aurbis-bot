import { ArbitrageDetector } from "@/lib/arbitrage-detector"
import { TradeExecutor } from "@/lib/trade-executor"
import { BinanceExchange } from "@/lib/exchanges/binance"
import { BybitExchange } from "@/lib/exchanges/bybit"
import { OKXExchange } from "@/lib/exchanges/okx"
import { notificationService } from "@/lib/notification"
import { simulationEngine } from "@/lib/simulation/simulation-engine"
import { marketDataService } from "@/lib/market-data-service"
import fs from "fs"
import path from "path"
import { settingsService } from "@/lib/supabase/settings-client"

// Path to the service status file
const statusFilePath = path.join(process.cwd(), "data", "status.json")

// Ensure the data directory exists
const ensureDataDirectoryExists = () => {
  try {
    const dataDir = path.join(process.cwd(), "data")
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true })
    }
    return true
  } catch (error) {
    console.error("Error creating data directory:", error)
    return false
  }
}

// Default status
const defaultStatus = {
  live: {
    running: false,
    lastStart: null,
    lastCheck: null,
    errors: [],
  },
  simulation: {
    running: false,
    lastStart: null,
    lastCheck: null,
    errors: [],
  },
}

// Save status
const saveStatus = (status: any) => {
  ensureDataDirectoryExists()

  try {
    fs.writeFileSync(statusFilePath, JSON.stringify(status, null, 2))
    return true
  } catch (error) {
    console.error("Error saving status file:", error)
    return false
  }
}

// Load status
const loadStatus = () => {
  ensureDataDirectoryExists()

  if (!fs.existsSync(statusFilePath)) {
    fs.writeFileSync(statusFilePath, JSON.stringify(defaultStatus, null, 2))
    return defaultStatus
  }

  try {
    const statusData = fs.readFileSync(statusFilePath, "utf8")
    return JSON.parse(statusData)
  } catch (error) {
    console.error("Error reading status file:", error)
    return defaultStatus
  }
}

// Shared variables
let liveIntervalId: NodeJS.Timeout | null = null
let simulationIntervalId: NodeJS.Timeout | null = null
const exchanges = new Map()
let detector: ArbitrageDetector | null = null
let executor: TradeExecutor | null = null

// Initialize exchanges with environment variables
const initializeExchanges = () => {
  const binance = new BinanceExchange(process.env.BINANCE_API_KEY || "", process.env.BINANCE_API_SECRET || "")

  const bybit = new BybitExchange(process.env.BYBIT_API_KEY || "", process.env.BYBIT_API_SECRET || "")

  const okx = new OKXExchange(
    process.env.OKX_API_KEY || "",
    process.env.OKX_API_SECRET || "",
    process.env.OKX_PASSPHRASE || "",
  )

  exchanges.set("Binance", binance)
  exchanges.set("Bybit", bybit)
  exchanges.set("OKX", okx)

  return { binance, bybit, okx }
}

// Start the live trading process
export const startLiveTrading = async (userId?: string) => {
  try {
    // Load settings from database (user-specific or global)
    const settings = await settingsService.getUserSettings(userId)

    if (!settings || !settings.live.continuous) {
      return { success: false, error: "Live trading is not enabled in settings" }
    }

    // Check if already running
    if (liveIntervalId) {
      return { success: true, message: "Live trading is already running" }
    }

    // Initialize exchanges
    const { binance, bybit, okx } = initializeExchanges()

    // Connect to exchanges
    await Promise.all([binance.connect(), bybit.connect(), okx.connect()])

    // Initialize arbitrage detector and trade executor
    const tradingPairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
    detector = new ArbitrageDetector(exchanges, tradingPairs, settings.live.minSpread)
    executor = new TradeExecutor(exchanges, settings.live.tradeSize)

    // Start the continuous checking process
    const checkInterval = settings.live.checkInterval * 1000
    liveIntervalId = setInterval(async () => {
      try {
        // Update status
        const status = loadStatus()
        status.live.lastCheck = new Date().toISOString()
        saveStatus(status)

        // Detect arbitrage opportunities
        const opportunities = await detector!.detectOpportunities()

        // Execute trades if auto-trading is enabled
        if (settings.live.autoTrading && opportunities.length > 0) {
          // Sort opportunities by spread (highest first)
          opportunities.sort((a, b) => b.spread - a.spread)

          // Take the best opportunity
          const bestOpportunity = opportunities[0]

          // Execute the trade
          const result = await executor!.executeArbitrage(bestOpportunity)

          if (result.success) {
            notificationService.success(`Successful arbitrage trade: $${result.profit?.toFixed(2)} profit`)
          } else {
            notificationService.error(`Failed to execute arbitrage: ${result.error}`)
          }
        }
      } catch (error) {
        console.error("Error in live trading cycle:", error)

        // Log the error
        const status = loadStatus()
        status.live.errors.push({
          timestamp: new Date().toISOString(),
          message: error instanceof Error ? error.message : String(error),
        })

        // Keep only the last 100 errors
        if (status.live.errors.length > 100) {
          status.live.errors = status.live.errors.slice(-100)
        }

        saveStatus(status)
      }
    }, checkInterval)

    // Update status
    const status = loadStatus()
    status.live.running = true
    status.live.lastStart = new Date().toISOString()
    status.live.errors = []
    saveStatus(status)

    notificationService.info("Live trading started in 24/7 mode")
    return { success: true }
  } catch (error) {
    console.error("Failed to start live trading:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to start live trading",
    }
  }
}

// Stop the live trading process
export const stopLiveTrading = () => {
  if (liveIntervalId) {
    clearInterval(liveIntervalId)
    liveIntervalId = null

    // Disconnect from exchanges
    exchanges.forEach((exchange) => {
      exchange.disconnect()
    })

    // Update status
    const status = loadStatus()
    status.live.running = false
    saveStatus(status)

    notificationService.info("Live trading stopped")
    return { success: true }
  }

  return { success: true, message: "Live trading was not running" }
}

// Start the simulation process
export const startSimulation = async () => {
  const settings = await settingsService.getSimulationSettings()
  if (!settings || !settings.simulation.continuous) {
    return { success: false, error: "Simulation is not enabled in settings" }
  }

  // Check if already running
  if (simulationIntervalId) {
    return { success: true, message: "Simulation is already running" }
  }

  try {
    // Start market data service
    const marketStarted = await marketDataService.start()
    if (!marketStarted) {
      return { success: false, error: "Failed to start market data service" }
    }

    // Configure the simulation
    simulationEngine.setMinSpread(settings.simulation.minSpread)
    simulationEngine.setTradeSize(settings.simulation.tradeSize)

    // Always enable auto-trading for continuous operation
    settings.simulation.autoTrading = true

    // Start the simulation engine
    simulationEngine.start()

    // Update status
    const status = loadStatus()
    status.simulation.running = true
    status.simulation.lastStart = new Date().toISOString()
    status.simulation.errors = []
    saveStatus(status)

    // Set up a heartbeat to update the status and ensure continuous operation
    simulationIntervalId = setInterval(
      () => {
        const status = loadStatus()
        status.simulation.lastCheck = new Date().toISOString()
        saveStatus(status)

        // Ensure the market data service is still running
        if (!marketDataService.isServiceRunning()) {
          marketDataService.start()
        }
      },
      Math.min(settings.simulation.checkInterval * 1000, 5000),
    ) // Check at least every 5 seconds

    notificationService.info("Simulation started in 24/7 continuous trading mode")
    return { success: true }
  } catch (error) {
    console.error("Failed to start simulation:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to start simulation",
    }
  }
}

// Stop the simulation process
export const stopSimulation = () => {
  if (simulationIntervalId) {
    clearInterval(simulationIntervalId)
    simulationIntervalId = null

    // Stop the simulation engine
    simulationEngine.stop()

    // Stop the market data service
    marketDataService.stop()

    // Update status
    const status = loadStatus()
    status.simulation.running = false
    saveStatus(status)

    notificationService.info("Simulation stopped")
    return { success: true }
  }

  return { success: true, message: "Simulation was not running" }
}

// Check if processes should be running based on settings, and start/stop as needed
export const syncProcessesWithSettings = async () => {
  const settings = await settingsService.getGlobalSettings()
  if (!settings) {
    return { success: false, error: "Failed to load settings" }
  }

  const status = loadStatus()

  // Check live trading
  if (settings.live.continuous && !status.live.running) {
    await startLiveTrading()
  } else if (!settings.live.continuous && status.live.running) {
    stopLiveTrading()
  }

  // Check simulation
  if (settings.simulation.continuous && !status.simulation.running) {
    await startSimulation()
  } else if (!settings.simulation.continuous && status.simulation.running) {
    stopSimulation()
  }

  return { success: true }
}
