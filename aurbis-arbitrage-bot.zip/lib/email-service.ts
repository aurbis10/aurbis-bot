"use server"

import nodemailer from "nodemailer"
import { createServerSupabaseClient } from "./supabase/server"

// Create a transporter for sending emails
const transporter = nodemailer.createTransport({
  service: "gmail", // You can use other services like SendGrid, Mailgun, etc.
  auth: {
    user: process.env.EMAIL_USER || "", // Your email address
    pass: process.env.EMAIL_PASSWORD || "", // Your email password or app-specific password
  },
})

export async function sendVerificationEmail(email: string, code: string) {
  try {
    // Email content
    const mailOptions = {
      from: process.env.EMAIL_USER || "noreply@example.com",
      to: email,
      subject: "Verify Your Email for Aurbis Arbitrage Bot",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #333; text-align: center;">Email Verification</h2>
          <p style="color: #666; font-size: 16px;">Thank you for signing up for Aurbis Arbitrage Bot. Please use the verification code below to complete your registration:</p>
          <div style="background-color: #f5f5f5; padding: 15px; text-align: center; margin: 20px 0; border-radius: 5px;">
            <h1 style="color: #333; letter-spacing: 5px; font-size: 32px; margin: 0;">${code}</h1>
          </div>
          <p style="color: #666; font-size: 14px;">This code will expire in 30 minutes.</p>
          <p style="color: #666; font-size: 14px;">If you didn't request this verification, please ignore this email.</p>
          <div style="text-align: center; margin-top: 30px; color: #999; font-size: 12px;">
            <p>© ${new Date().getFullYear()} Aurbis Arbitrage Bot. All rights reserved.</p>
          </div>
        </div>
      `,
    }

    // Send the email
    const info = await transporter.sendMail(mailOptions)
    console.log("Email sent:", info.response)

    return { success: true }
  } catch (error) {
    console.error("Error sending email:", error)
    return { success: false, error }
  }
}

export async function generateVerificationCode(email: string) {
  const supabase = createServerSupabaseClient()

  // Generate a 6-digit code
  const code = Math.floor(100000 + Math.random() * 900000).toString()

  // Delete any existing codes for this email
  await supabase.from("verification_codes").delete().eq("email", email)

  // Save the new code
  const { error } = await supabase.from("verification_codes").insert({
    email,
    code,
    expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString(), // Expires in 30 minutes
  })

  if (error) {
    console.error("Error generating verification code:", error)
    return { success: false, error }
  }

  // Send the email
  const emailResult = await sendVerificationEmail(email, code)

  if (!emailResult.success) {
    return { success: false, error: emailResult.error || "Failed to send verification email" }
  }

  return { success: true, code }
}
