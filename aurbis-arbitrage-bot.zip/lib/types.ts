export interface PriceData {
  exchange: string
  symbol: string
  price: number
  bid: number
  ask: number
  timestamp: Date
}

export interface ArbitrageOpportunity {
  buyExchange: string
  sellExchange: string
  symbol: string
  buyPrice: number
  sellPrice: number
  spread: number
  timestamp: Date
}

export interface Exchange {
  connect(): Promise<boolean>
  getPrice(symbol: string): Promise<PriceData>
  executeBuy(symbol: string, amount: number): Promise<boolean>
  executeSell(symbol: string, amount: number): Promise<boolean>
  getBalance(currency: string): Promise<number>
  disconnect(): void
}

export interface TradeResult {
  success: boolean
  profit?: number
  error?: string
}

export interface BotConfig {
  minSpread: number
  tradeSize: number
  checkInterval: number
  autoTrade: boolean
  tradingPairs: string[]
}
