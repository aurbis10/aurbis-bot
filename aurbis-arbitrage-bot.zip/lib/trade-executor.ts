import type { Exchange, ArbitrageOpportunity, TradeResult } from "@/lib/types"
// Import the notification service at the top of the file
import { notificationService } from "@/lib/notification"

export class TradeExecutor {
  private exchanges: Map<string, Exchange>
  private tradeSize: number

  constructor(exchanges: Map<string, Exchange>, tradeSize = 100) {
    this.exchanges = exchanges
    this.tradeSize = tradeSize
  }

  async executeArbitrage(opportunity: ArbitrageOpportunity): Promise<TradeResult> {
    try {
      const { buyExchange, sellExchange, symbol, buyPrice, sellPrice } = opportunity

      // Get the exchange instances
      const buyExchangeInstance = this.exchanges.get(buyExchange)
      const sellExchangeInstance = this.exchanges.get(sellExchange)

      if (!buyExchangeInstance || !sellExchangeInstance) {
        return {
          success: false,
          error: `Exchange not found: ${!buyExchangeInstance ? buyExchange : sellExchange}`,
        }
      }

      // Calculate the amount to buy based on the trade size
      const baseCurrency = symbol.split("/")[0] // e.g., "BTC" from "BTC/USDT"
      const quoteCurrency = symbol.split("/")[1] // e.g., "USDT" from "BTC/USDT"
      const amount = this.tradeSize / buyPrice

      // Check if we have enough balance
      const buyBalance = await buyExchangeInstance.getBalance(quoteCurrency)
      if (buyBalance < this.tradeSize) {
        return {
          success: false,
          error: `Insufficient ${quoteCurrency} balance on ${buyExchange}`,
        }
      }

      // Execute the buy order
      const buySuccess = await buyExchangeInstance.executeBuy(symbol, amount)
      if (!buySuccess) {
        notificationService.error(`Failed to execute buy order on ${buyExchange}`)
        return {
          success: false,
          error: `Failed to execute buy order on ${buyExchange}`,
        }
      }
      notificationService.info(`Successfully bought ${amount.toFixed(6)} ${baseCurrency} on ${buyExchange}`)

      // Execute the sell order
      const sellSuccess = await sellExchangeInstance.executeSell(symbol, amount)
      if (!sellSuccess) {
        notificationService.error(`Failed to execute sell order on ${sellExchange}`)
        // In a real implementation, we would need to handle the case where the buy succeeded but the sell failed
        return {
          success: false,
          error: `Failed to execute sell order on ${sellExchange}`,
        }
      }
      notificationService.info(`Successfully sold ${amount.toFixed(6)} ${baseCurrency} on ${sellExchange}`)

      // Calculate profit
      const profit = (sellPrice - buyPrice) * amount
      notificationService.success(`Arbitrage completed: ${profit.toFixed(2)} ${quoteCurrency} profit`)

      return {
        success: true,
        profit,
      }
    } catch (error) {
      console.error("Error executing arbitrage:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : String(error),
      }
    }
  }

  setTradeSize(tradeSize: number): void {
    this.tradeSize = tradeSize
  }
}
