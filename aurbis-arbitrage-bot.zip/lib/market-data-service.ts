"use client"

import type { PriceData } from "@/lib/types"
import { simulationEngine } from "@/lib/simulation/simulation-engine"
import { notificationService } from "@/lib/notification"

class MarketDataService {
  private isRunning = false
  private intervalId: NodeJS.Timeout | null = null
  private updateInterval = 3000 // 3 seconds - more frequent checks for opportunities
  private tradingPairs: string[] = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
  private priceListeners: ((prices: Map<string, PriceData[]>) => void)[] = []
  private latestPrices: Map<string, PriceData[]> = new Map()

  // Market volatility simulation
  private volatilityLevel: "low" | "medium" | "high" = "low"
  private volatilityTimer: NodeJS.Timeout | null = null
  private spreadMultiplier = 1.0

  public async start(): Promise<boolean> {
    if (this.isRunning) {
      return true
    }

    try {
      this.isRunning = true
      notificationService.info("Market data service started")

      // Start volatility simulation
      this.startVolatilitySimulation()

      // Fetch prices immediately
      await this.fetchPrices()

      // Then set up interval for continuous fetching
      this.intervalId = setInterval(() => this.fetchPrices(), this.updateInterval)

      return true
    } catch (error) {
      console.error("Failed to start market data service:", error)
      notificationService.error("Failed to start market data service")
      return false
    }
  }

  public stop(): void {
    if (!this.isRunning) {
      return
    }

    if (this.intervalId) {
      clearInterval(this.intervalId)
      this.intervalId = null
    }

    if (this.volatilityTimer) {
      clearInterval(this.volatilityTimer)
      this.volatilityTimer = null
    }

    this.isRunning = false
    notificationService.info("Market data service stopped")
  }

  private startVolatilitySimulation(): void {
    // Change volatility levels randomly every 30-90 seconds
    this.volatilityTimer = setInterval(
      () => {
        const rand = Math.random()

        if (rand < 0.6) {
          // 60% chance of low volatility
          this.volatilityLevel = "low"
          this.spreadMultiplier = 1.0
        } else if (rand < 0.9) {
          // 30% chance of medium volatility
          this.volatilityLevel = "medium"
          this.spreadMultiplier = 1.5
          notificationService.info("Market volatility increasing to medium levels")
        } else {
          // 10% chance of high volatility
          this.volatilityLevel = "high"
          this.spreadMultiplier = 2.5
          notificationService.warning("High market volatility detected - spreads widening")
        }
      },
      30000 + Math.random() * 60000,
    ) // 30-90 seconds
  }

  public isServiceRunning(): boolean {
    return this.isRunning
  }

  public setUpdateInterval(interval: number): void {
    this.updateInterval = interval
    if (this.isRunning && this.intervalId) {
      clearInterval(this.intervalId)
      this.intervalId = setInterval(() => this.fetchPrices(), this.updateInterval)
    }
  }

  public getLatestPrices(): Map<string, PriceData[]> {
    return new Map(this.latestPrices)
  }

  public getCurrentVolatility(): string {
    return this.volatilityLevel
  }

  public subscribeToPrices(callback: (prices: Map<string, PriceData[]>) => void): () => void {
    this.priceListeners.push(callback)
    return () => {
      this.priceListeners = this.priceListeners.filter((listener) => listener !== callback)
    }
  }

  private async fetchPrices(): Promise<void> {
    try {
      for (const pair of this.tradingPairs) {
        try {
          // Fetch prices from the server API
          const response = await fetch(`/api/market-data?pair=${encodeURIComponent(pair)}`)

          if (!response.ok) {
            throw new Error(`Failed to fetch prices: ${response.statusText}`)
          }

          const data = await response.json()

          if (!data.success || !data.prices) {
            throw new Error("Invalid response from server")
          }

          // Apply volatility to the prices
          const prices: PriceData[] = data.prices.map((price: PriceData) => {
            // Apply volatility to the spread
            const baseSpread = price.ask - price.bid
            const adjustedSpread = baseSpread * this.spreadMultiplier

            // Adjust the bid and ask prices to reflect the new spread
            const midPrice = (price.bid + price.ask) / 2
            const halfSpread = adjustedSpread / 2

            return {
              ...price,
              bid: midPrice - halfSpread,
              ask: midPrice + halfSpread,
              // Add volatility flag for UI
              volatility: this.volatilityLevel,
            }
          })

          // Store the latest prices
          this.latestPrices.set(pair, prices)

          // Always check for arbitrage opportunities when simulation is running
          if (simulationEngine.isSimulationRunning()) {
            // Try to find opportunities more aggressively to ensure continuous trading
            const opportunity = simulationEngine.detectArbitrageOpportunity(prices)
            if (opportunity) {
              simulationEngine.executeArbitrageTrade(opportunity)
            }
          }
        } catch (error) {
          console.error(`Error fetching prices for ${pair}:`, error)
        }
      }

      // Notify listeners
      this.notifyPriceListeners()
    } catch (error) {
      console.error("Error fetching prices:", error)
    }
  }

  private notifyPriceListeners(): void {
    this.priceListeners.forEach((listener) => listener(this.latestPrices))
  }
}

// Create a singleton instance
export const marketDataService = new MarketDataService()
