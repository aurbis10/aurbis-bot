// In-memory settings store as a fallback
let inMemorySettings = {
  live: {
    autoTrading: false,
    continuous: false,
    minSpread: 1.3,
    tradeSize: 100,
    checkInterval: 3,
  },
  simulation: {
    autoTrading: false,
    continuous: false,
    minSpread: 1.3,
    tradeSize: 50,
    checkInterval: 3,
  },
}

export const settingsStore = {
  getSettings: () => {
    return { ...inMemorySettings }
  },

  updateSettings: (newSettings: any) => {
    inMemorySettings = {
      ...inMemorySettings,
      ...newSettings,
    }
    return { ...inMemorySettings }
  },

  updateLiveSettings: (liveSettings: any) => {
    inMemorySettings.live = {
      ...inMemorySettings.live,
      ...liveSettings,
    }
    return { ...inMemorySettings }
  },

  updateSimulationSettings: (simulationSettings: any) => {
    inMemorySettings.simulation = {
      ...inMemorySettings.simulation,
      ...simulationSettings,
    }
    return { ...inMemorySettings }
  },
}
