import type { PriceData, ArbitrageOpportunity } from "@/lib/types"
import { notificationService } from "@/lib/notification"

export interface SimulatedAccount {
  exchange: string
  balances: {
    [currency: string]: number
  }
  trades: SimulatedTrade[]
}

export interface SimulatedTrade {
  id: string
  timestamp: Date
  pair: string
  type: "buy" | "sell"
  price: number
  amount: number
  total: number
  fee: number
  status: "completed" | "failed" | "pending"
  latency?: number // Time in ms it took to execute
  slippage?: number // Price slippage as a percentage
  liquidity?: number // Available liquidity at time of trade
}

export interface ArbitrageTrade {
  id: string
  timestamp: Date
  buyExchange: string
  sellExchange: string
  pair: string
  buyPrice: number
  sellPrice: number
  amount: number
  spread: number
  profit: number
  profitPercentage: number
  status: "completed" | "failed" | "pending"
  buyTrade: SimulatedTrade
  sellTrade: SimulatedTrade
  totalLatency?: number // Total latency for the entire arbitrage
  netProfit?: number // Profit after all fees, slippage, etc.
  executionQuality?: number // Score from 0-100 on execution quality
}

export interface SimulationStats {
  totalTrades: number
  successfulTrades: number
  failedTrades: number
  winRate: number
  totalProfit: number
  averageProfit: number
  largestProfit: number
  largestLoss: number
  initialBalance: number
  currentBalance: number
  roi: number
  averageLatency: number
  averageSlippage: number
  totalFees: number
  netProfitAfterFees: number
  profitFactor: number // Ratio of gross profits to gross losses
  volatilityImpact: number // How volatility affected performance
}

export interface MarketCondition {
  volatility: "low" | "medium" | "high"
  liquidity: "low" | "medium" | "high"
  trend: "bullish" | "bearish" | "sideways"
  spreadWidth: "tight" | "normal" | "wide"
}

class SimulationEngine {
  private continuousTradingInterval: NodeJS.Timeout | null = null
  private targetWinRate = 95
  private accounts: Map<string, SimulatedAccount> = new Map()
  private arbitrageTrades: ArbitrageTrade[] = []
  private initialBalance = 100 // USDT
  private fees: Map<string, number> = new Map()
  private minSpread = 1.3
  private tradeSize = 50 // USDT
  private isRunning = false
  private startTime: Date | null = null
  private listeners: ((stats: SimulationStats) => void)[] = []

  // Real-world simulation parameters
  private latencyModel: Map<string, { min: number; max: number }> = new Map()
  private slippageModel: Map<string, { min: number; max: number }> = new Map()
  private liquidityModel: Map<string, { [pair: string]: number }> = new Map()
  private currentMarketCondition: MarketCondition = {
    volatility: "low",
    liquidity: "medium",
    trend: "sideways",
    spreadWidth: "normal",
  }
  private volatilityHistory: number[] = []
  private compoundProfits = true // Whether to reinvest profits
  private initialInvestment = 100 // Used for ROI calculation

  constructor() {
    this.initialBalance = this.initialInvestment / 3 // Divide initial investment among 3 exchanges
    // Initialize exchange accounts with 100 USDT each
    this.initializeAccount("Binance")
    this.initializeAccount("Bybit")
    this.initializeAccount("OKX")

    // Set default fees for each exchange (in percentage)
    this.fees.set("Binance", 0.1)
    this.fees.set("Bybit", 0.1)
    this.fees.set("OKX", 0.1)

    // Initialize latency models (in milliseconds)
    this.latencyModel.set("Binance", { min: 150, max: 500 })
    this.latencyModel.set("Bybit", { min: 200, max: 700 })
    this.latencyModel.set("OKX", { min: 180, max: 600 })

    // Initialize slippage models (in percentage)
    this.slippageModel.set("Binance", { min: 0.01, max: 0.2 })
    this.slippageModel.set("Bybit", { min: 0.02, max: 0.3 })
    this.slippageModel.set("OKX", { min: 0.015, max: 0.25 })

    // Initialize liquidity models (in base currency units)
    this.liquidityModel.set("Binance", {
      "BTC/USDT": 10,
      "ETH/USDT": 100,
      "SOL/USDT": 1000,
    })
    this.liquidityModel.set("Bybit", {
      "BTC/USDT": 8,
      "ETH/USDT": 80,
      "SOL/USDT": 800,
    })
    this.liquidityModel.set("OKX", {
      "BTC/USDT": 9,
      "ETH/USDT": 90,
      "SOL/USDT": 900,
    })

    // Start market condition updates
    this.startMarketConditionUpdates()
  }

  private initializeAccount(exchange: string): void {
    this.accounts.set(exchange, {
      exchange,
      balances: {
        USDT: this.initialBalance,
        BTC: 0,
        ETH: 0,
        SOL: 0,
      },
      trades: [],
    })
  }

  private startMarketConditionUpdates(): void {
    // Update market conditions every 30-60 seconds
    setInterval(
      () => {
        this.updateMarketConditions()
      },
      30000 + Math.random() * 30000,
    )
  }

  private updateMarketConditions(): void {
    // Randomly change market conditions
    const volatilityOptions: MarketCondition["volatility"][] = ["low", "medium", "high"]
    const liquidityOptions: MarketCondition["liquidity"][] = ["low", "medium", "high"]
    const trendOptions: MarketCondition["trend"][] = ["bullish", "bearish", "sideways"]
    const spreadOptions: MarketCondition["spreadWidth"][] = ["tight", "normal", "wide"]

    // Gradually shift market conditions (don't jump from low to high instantly)
    const currentVolatilityIndex = volatilityOptions.indexOf(this.currentMarketCondition.volatility)
    const newVolatilityIndex = Math.max(
      0,
      Math.min(
        volatilityOptions.length - 1,
        currentVolatilityIndex + (Math.random() > 0.5 ? 1 : -1) * (Math.random() > 0.7 ? 1 : 0),
      ),
    )

    this.currentMarketCondition = {
      volatility: volatilityOptions[newVolatilityIndex],
      liquidity: liquidityOptions[Math.floor(Math.random() * liquidityOptions.length)],
      trend: trendOptions[Math.floor(Math.random() * trendOptions.length)],
      spreadWidth: spreadOptions[Math.floor(Math.random() * spreadOptions.length)],
    }

    // Log market condition change
    notificationService.info(
      `Market conditions updated: Volatility ${this.currentMarketCondition.volatility}, Liquidity ${this.currentMarketCondition.liquidity}`,
    )

    // Update exchange parameters based on new market conditions
    this.updateExchangeParameters()
  }

  private updateExchangeParameters(): void {
    // Adjust latency based on market conditions
    const latencyMultiplier =
      this.currentMarketCondition.volatility === "high"
        ? 1.5
        : this.currentMarketCondition.volatility === "medium"
          ? 1.2
          : 1.0

    // Adjust slippage based on market conditions
    const slippageMultiplier =
      this.currentMarketCondition.volatility === "high"
        ? 2.0
        : this.currentMarketCondition.volatility === "medium"
          ? 1.5
          : 1.0

    // Adjust liquidity based on market conditions
    const liquidityMultiplier =
      this.currentMarketCondition.liquidity === "high"
        ? 1.5
        : this.currentMarketCondition.liquidity === "medium"
          ? 1.0
          : 0.6

    // Update exchange parameters
    for (const exchange of ["Binance", "Bybit", "OKX"]) {
      // Update latency model
      const baseLatency = this.latencyModel.get(exchange)!
      this.latencyModel.set(exchange, {
        min: baseLatency.min * latencyMultiplier,
        max: baseLatency.max * latencyMultiplier,
      })

      // Update slippage model
      const baseSlippage = this.slippageModel.get(exchange)!
      this.slippageModel.set(exchange, {
        min: baseSlippage.min * slippageMultiplier,
        max: baseSlippage.max * slippageMultiplier,
      })

      // Update liquidity model
      const baseLiquidity = this.liquidityModel.get(exchange)!
      const updatedLiquidity: { [pair: string]: number } = {}
      for (const pair in baseLiquidity) {
        updatedLiquidity[pair] = baseLiquidity[pair] * liquidityMultiplier
      }
      this.liquidityModel.set(exchange, updatedLiquidity)
    }
  }

  public getAccount(exchange: string): SimulatedAccount | undefined {
    return this.accounts.get(exchange)
  }

  public getAllAccounts(): SimulatedAccount[] {
    return Array.from(this.accounts.values())
  }

  public getArbitrageTrades(): ArbitrageTrade[] {
    return [...this.arbitrageTrades]
  }

  public getLatestArbitrageTrades(count = 10): ArbitrageTrade[] {
    return [...this.arbitrageTrades].slice(0, count)
  }

  public getStats(): SimulationStats {
    const totalTrades = this.arbitrageTrades.length
    const successfulTrades = this.arbitrageTrades.filter((trade) => trade.status === "completed").length
    const failedTrades = this.arbitrageTrades.filter((trade) => trade.status === "failed").length

    const completedTrades = this.arbitrageTrades.filter((trade) => trade.status === "completed")
    const profits = completedTrades.map((trade) => trade.profit)

    const totalProfit = profits.reduce((sum, profit) => sum + profit, 0)
    const averageProfit = profits.length > 0 ? totalProfit / profits.length : 0
    const largestProfit = profits.length > 0 ? Math.max(...profits) : 0
    const largestLoss = profits.length > 0 ? Math.min(...profits) : 0

    // Calculate total balance across all exchanges
    let totalBalance = 0
    this.accounts.forEach((account) => {
      totalBalance += account.balances.USDT
    })

    // Calculate ROI based on initial investment, not per-exchange balance
    const totalInitialBalance = this.initialInvestment
    const roi = totalTrades > 0 ? (totalBalance / totalInitialBalance - 1) * 100 : 0

    // Calculate average latency
    const latencies = completedTrades
      .filter((trade) => trade.totalLatency !== undefined)
      .map((trade) => trade.totalLatency!)
    const averageLatency =
      latencies.length > 0 ? latencies.reduce((sum, latency) => sum + latency, 0) / latencies.length : 0

    // Calculate average slippage
    const slippages = completedTrades.flatMap((trade) => [trade.buyTrade.slippage || 0, trade.sellTrade.slippage || 0])
    const averageSlippage =
      slippages.length > 0 ? slippages.reduce((sum, slippage) => sum + slippage, 0) / slippages.length : 0

    // Calculate total fees
    const totalFees = completedTrades
      .flatMap((trade) => [trade.buyTrade.fee || 0, trade.sellTrade.fee || 0])
      .reduce((sum, fee) => sum + fee, 0)

    // Calculate net profit after fees
    const netProfitAfterFees = totalProfit - totalFees

    // Calculate profit factor (ratio of gross profits to gross losses)
    const grossProfits = profits.filter((p) => p > 0).reduce((sum, p) => sum + p, 0)
    const grossLosses = Math.abs(profits.filter((p) => p < 0).reduce((sum, p) => sum + p, 0))
    const profitFactor = grossLosses > 0 ? grossProfits / grossLosses : grossProfits > 0 ? Number.POSITIVE_INFINITY : 0

    // Calculate volatility impact
    const volatilityImpact = this.calculateVolatilityImpact()

    return {
      totalTrades,
      successfulTrades,
      failedTrades,
      winRate: totalTrades > 0 ? (successfulTrades / totalTrades) * 100 : 0,
      totalProfit,
      averageProfit,
      largestProfit,
      largestLoss,
      initialBalance: totalInitialBalance,
      currentBalance: totalBalance,
      roi,
      averageLatency,
      averageSlippage,
      totalFees,
      netProfitAfterFees,
      profitFactor,
      volatilityImpact,
    }
  }

  private calculateVolatilityImpact(): number {
    if (this.volatilityHistory.length < 2) return 0

    // Calculate standard deviation of profit percentages
    const mean = this.volatilityHistory.reduce((sum, val) => sum + val, 0) / this.volatilityHistory.length
    const squaredDiffs = this.volatilityHistory.map((val) => Math.pow(val - mean, 2))
    const variance = squaredDiffs.reduce((sum, val) => sum + val, 0) / squaredDiffs.length
    const stdDev = Math.sqrt(variance)

    // Normalize to a 0-100 scale where higher means more impact
    return Math.min(100, stdDev * 10)
  }

  public setMinSpread(minSpread: number): void {
    this.minSpread = minSpread
  }

  public setTradeSize(tradeSize: number): void {
    this.tradeSize = tradeSize
  }

  public setCompoundProfits(compound: boolean): void {
    this.compoundProfits = compound
  }

  public setInitialInvestment(amount: number): void {
    this.initialInvestment = amount
  }

  public start(): void {
    this.isRunning = true
    this.startTime = new Date()

    // Set up a timer to ensure continuous trading
    if (this.continuousTradingInterval) {
      clearInterval(this.continuousTradingInterval)
    }

    this.continuousTradingInterval = setInterval(() => {
      this.ensureContinuousTrading()
    }, 5000) // Check every 5 seconds

    notificationService.info("Simulation started in continuous trading mode")
  }

  public stop(): void {
    this.isRunning = false

    if (this.continuousTradingInterval) {
      clearInterval(this.continuousTradingInterval)
      this.continuousTradingInterval = null
    }

    notificationService.info("Simulation stopped")
  }

  public isSimulationRunning(): boolean {
    return this.isRunning
  }

  public detectArbitrageOpportunity(prices: PriceData[]): ArbitrageOpportunity | null {
    if (!this.isRunning || prices.length < 2) {
      return null
    }

    // Make it more likely to find opportunities based on the target win rate
    // Higher win rate = more opportunities
    if (Math.random() * 100 > this.targetWinRate) {
      return null // Randomly skip some opportunities based on win rate
    }

    let bestOpportunity: ArbitrageOpportunity | null = null
    let bestSpread = 0

    // Find arbitrage opportunities
    for (let i = 0; i < prices.length; i++) {
      for (let j = 0; j < prices.length; j++) {
        if (i === j) continue

        const buyExchange = prices[i].exchange
        const sellExchange = prices[j].exchange
        const buyPrice = prices[i].ask // We buy at the ask price
        const sellPrice = prices[j].bid // We sell at the bid price

        // Calculate fees
        const buyFee = this.fees.get(buyExchange) || 0.1
        const sellFee = this.fees.get(sellExchange) || 0.1

        // Apply slippage based on market conditions
        const buySlippage = this.getSlippage(buyExchange)
        const sellSlippage = this.getSlippage(sellExchange)

        // Adjust prices with slippage
        const adjustedBuyPrice = buyPrice * (1 + buySlippage / 100)
        const adjustedSellPrice = sellPrice * (1 - sellSlippage / 100)

        // Calculate the spread after fees and slippage
        const buyPriceWithFee = adjustedBuyPrice * (1 + buyFee / 100)
        const sellPriceWithFee = adjustedSellPrice * (1 - sellFee / 100)
        const spread = (sellPriceWithFee / buyPriceWithFee - 1) * 100

        // Check if the spread is above the minimum threshold and better than previous opportunities
        if (spread >= this.minSpread && spread > bestSpread) {
          // Check liquidity
          const pair = prices[i].symbol
          const buyLiquidity = this.getLiquidity(buyExchange, pair)
          const sellLiquidity = this.getLiquidity(sellExchange, pair)

          // Calculate the maximum amount we can trade based on liquidity
          const amount = this.tradeSize / adjustedBuyPrice

          // Only consider the opportunity if there's enough liquidity
          if (amount <= buyLiquidity && amount <= sellLiquidity) {
            bestSpread = spread
            bestOpportunity = {
              buyExchange,
              sellExchange,
              symbol: prices[i].symbol,
              buyPrice: adjustedBuyPrice,
              sellPrice: adjustedSellPrice,
              spread,
              timestamp: new Date(),
            }
          }
        }
      }
    }

    return bestOpportunity
  }

  public executeArbitrageTrade(opportunity: ArbitrageOpportunity): ArbitrageTrade | null {
    if (!this.isRunning) {
      return null
    }

    const { buyExchange, sellExchange, symbol, buyPrice, sellPrice, spread } = opportunity

    // Get the accounts
    const buyAccount = this.accounts.get(buyExchange)
    const sellAccount = this.accounts.get(sellExchange)

    if (!buyAccount || !sellAccount) {
      notificationService.error(`Account not found: ${!buyAccount ? buyExchange : sellExchange}`)
      return null
    }

    // Calculate the amount to buy based on the trade size
    const baseCurrency = symbol.split("/")[0] // e.g., "BTC" from "BTC/USDT"
    const quoteCurrency = symbol.split("/")[1] // e.g., "USDT" from "BTC/USDT"

    // If compounding profits, use the current balance for trade size
    const effectiveTradeSize = this.compoundProfits
      ? Math.min(buyAccount.balances[quoteCurrency], this.tradeSize)
      : this.tradeSize

    const amount = effectiveTradeSize / buyPrice

    // Check if we have enough balance
    if (buyAccount.balances[quoteCurrency] < effectiveTradeSize) {
      notificationService.warning(`Insufficient ${quoteCurrency} balance on ${buyExchange}`)
      return null
    }

    // Check liquidity
    const buyLiquidity = this.getLiquidity(buyExchange, symbol)
    const sellLiquidity = this.getLiquidity(sellExchange, symbol)

    if (amount > buyLiquidity) {
      notificationService.warning(`Insufficient liquidity on ${buyExchange} for ${symbol}`)
      return null
    }

    if (amount > sellLiquidity) {
      notificationService.warning(`Insufficient liquidity on ${sellExchange} for ${symbol}`)
      return null
    }

    // Generate a unique ID for the trade
    const tradeId = Math.random().toString(36).substring(2, 15)

    // Simulate latency for buy order
    const buyLatency = this.getLatency(buyExchange)

    // Simulate slippage for buy order
    const buySlippage = this.getSlippage(buyExchange)
    const adjustedBuyPrice = buyPrice * (1 + buySlippage / 100)

    // Execute the buy trade
    const buyFee = (this.fees.get(buyExchange) || 0.1) / 100
    const buyFeeAmount = effectiveTradeSize * buyFee
    const buyTrade: SimulatedTrade = {
      id: `buy-${tradeId}`,
      timestamp: new Date(),
      pair: symbol,
      type: "buy",
      price: adjustedBuyPrice,
      amount,
      total: effectiveTradeSize,
      fee: buyFeeAmount,
      status: Math.random() > 0.02 ? "completed" : "failed", // 98% success rate for buy orders
      latency: buyLatency,
      slippage: buySlippage,
      liquidity: buyLiquidity,
    }

    // If buy failed, return a failed arbitrage trade
    if (buyTrade.status === "failed") {
      const failedArbitrageTrade: ArbitrageTrade = {
        id: tradeId,
        timestamp: new Date(),
        buyExchange,
        sellExchange,
        pair: symbol,
        buyPrice: adjustedBuyPrice,
        sellPrice,
        amount,
        spread,
        profit: 0,
        profitPercentage: 0,
        status: "failed",
        buyTrade,
        sellTrade: {
          id: `sell-${tradeId}`,
          timestamp: new Date(),
          pair: symbol,
          type: "sell",
          price: sellPrice,
          amount,
          total: 0,
          fee: 0,
          status: "pending",
          latency: 0,
          slippage: 0,
          liquidity: sellLiquidity,
        },
        totalLatency: buyLatency,
        netProfit: -buyFeeAmount,
        executionQuality: 0,
      }

      this.arbitrageTrades.unshift(failedArbitrageTrade)
      notificationService.error(`Failed to execute buy order on ${buyExchange}`)
      this.notifyListeners()
      return failedArbitrageTrade
    }

    // Update buy account balances
    buyAccount.balances[quoteCurrency] -= effectiveTradeSize
    buyAccount.balances[baseCurrency] += amount - amount * buyFee
    buyAccount.trades.push(buyTrade)

    // Simulate latency for sell order
    const sellLatency = this.getLatency(sellExchange)

    // Simulate slippage for sell order
    const sellSlippage = this.getSlippage(sellExchange)
    const adjustedSellPrice = sellPrice * (1 - sellSlippage / 100)

    // Execute the sell trade
    const sellFee = (this.fees.get(sellExchange) || 0.1) / 100
    const sellTotal = amount * adjustedSellPrice
    const sellFeeAmount = sellTotal * sellFee
    const sellTrade: SimulatedTrade = {
      id: `sell-${tradeId}`,
      timestamp: new Date(Date.now() + buyLatency), // Sell happens after buy completes
      pair: symbol,
      type: "sell",
      price: adjustedSellPrice,
      amount,
      total: sellTotal,
      fee: sellFeeAmount,
      status: Math.random() > 0.01 ? "completed" : "failed", // 99% success rate for sell orders
      latency: sellLatency,
      slippage: sellSlippage,
      liquidity: sellLiquidity,
    }

    // If sell failed, we need to revert the buy (in a real system, you'd need to handle this differently)
    if (sellTrade.status === "failed") {
      // Revert buy account balances
      buyAccount.balances[quoteCurrency] += effectiveTradeSize
      buyAccount.balances[baseCurrency] -= amount - amount * buyFee

      const failedArbitrageTrade: ArbitrageTrade = {
        id: tradeId,
        timestamp: new Date(),
        buyExchange,
        sellExchange,
        pair: symbol,
        buyPrice: adjustedBuyPrice,
        sellPrice: adjustedSellPrice,
        amount,
        spread,
        profit: -buyFeeAmount, // We lost the buy fee
        profitPercentage: (-buyFeeAmount / effectiveTradeSize) * 100,
        status: "failed",
        buyTrade,
        sellTrade,
        totalLatency: buyLatency + sellLatency,
        netProfit: -buyFeeAmount,
        executionQuality: 20, // Low quality due to failure
      }

      this.arbitrageTrades.unshift(failedArbitrageTrade)
      notificationService.error(`Failed to execute sell order on ${sellExchange}`)
      this.notifyListeners()
      return failedArbitrageTrade
    }

    // Update sell account balances
    sellAccount.balances[baseCurrency] -= amount
    sellAccount.balances[quoteCurrency] += sellTotal - sellFeeAmount
    sellAccount.trades.push(sellTrade)

    // Calculate profit
    const profit = sellTotal - effectiveTradeSize - buyFeeAmount - sellFeeAmount
    const profitPercentage = (profit / effectiveTradeSize) * 100

    // Calculate total latency
    const totalLatency = buyLatency + sellLatency

    // Calculate execution quality (0-100)
    const executionQuality = this.calculateExecutionQuality(spread, buySlippage, sellSlippage, totalLatency, profit > 0)

    // Create the arbitrage trade record
    const arbitrageTrade: ArbitrageTrade = {
      id: tradeId,
      timestamp: new Date(),
      buyExchange,
      sellExchange,
      pair: symbol,
      buyPrice: adjustedBuyPrice,
      sellPrice: adjustedSellPrice,
      amount,
      spread,
      profit,
      profitPercentage,
      status: "completed",
      buyTrade,
      sellTrade,
      totalLatency,
      netProfit: profit,
      executionQuality,
    }

    // Add to the list of arbitrage trades
    this.arbitrageTrades.unshift(arbitrageTrade)

    // Add to volatility history for impact analysis
    this.volatilityHistory.push(profitPercentage)
    if (this.volatilityHistory.length > 50) {
      this.volatilityHistory.shift() // Keep only the last 50 trades
    }

    // Notify about the successful trade
    if (profit > 0) {
      notificationService.success(`Arbitrage completed: $${profit.toFixed(2)} profit (${profitPercentage.toFixed(2)}%)`)
    } else {
      notificationService.warning(
        `Arbitrage completed with loss: $${profit.toFixed(2)} (${profitPercentage.toFixed(2)}%)`,
      )
    }

    this.notifyListeners()
    return arbitrageTrade
  }

  private getLatency(exchange: string): number {
    const model = this.latencyModel.get(exchange)
    if (!model) return 200 // Default latency

    // Generate random latency within the model range
    const baseLatency = model.min + Math.random() * (model.max - model.min)

    // Apply market condition multipliers
    let multiplier = 1.0

    // High volatility increases latency
    if (this.currentMarketCondition.volatility === "high") {
      multiplier *= 1.5
    } else if (this.currentMarketCondition.volatility === "medium") {
      multiplier *= 1.2
    }

    // Low liquidity increases latency
    if (this.currentMarketCondition.liquidity === "low") {
      multiplier *= 1.3
    }

    return Math.round(baseLatency * multiplier)
  }

  private getSlippage(exchange: string): number {
    const model = this.slippageModel.get(exchange)
    if (!model) return 0.05 // Default slippage

    // Generate random slippage within the model range
    const baseSlippage = model.min + Math.random() * (model.max - model.min)

    // Apply market condition multipliers
    let multiplier = 1.0

    // High volatility increases slippage
    if (this.currentMarketCondition.volatility === "high") {
      multiplier *= 2.0
    } else if (this.currentMarketCondition.volatility === "medium") {
      multiplier *= 1.5
    }

    // Low liquidity increases slippage
    if (this.currentMarketCondition.liquidity === "low") {
      multiplier *= 1.8
    } else if (this.currentMarketCondition.liquidity === "medium") {
      multiplier *= 1.2
    }

    // Wide spreads increase slippage
    if (this.currentMarketCondition.spreadWidth === "wide") {
      multiplier *= 1.4
    } else if (this.currentMarketCondition.spreadWidth === "normal") {
      multiplier *= 1.1
    }

    return baseSlippage * multiplier
  }

  private getLiquidity(exchange: string, pair: string): number {
    const model = this.liquidityModel.get(exchange)
    if (!model || !model[pair]) return 999999 // Default to high liquidity

    // Get base liquidity for this exchange and pair
    const baseLiquidity = model[pair]

    // Apply market condition multipliers
    let multiplier = 1.0

    // Market liquidity directly affects available liquidity
    if (this.currentMarketCondition.liquidity === "high") {
      multiplier *= 1.5
    } else if (this.currentMarketCondition.liquidity === "low") {
      multiplier *= 0.6
    }

    // Volatility can reduce liquidity
    if (this.currentMarketCondition.volatility === "high") {
      multiplier *= 0.7
    }

    // Trending markets can affect liquidity
    if (this.currentMarketCondition.trend === "bullish") {
      multiplier *= 1.2 // More liquidity in bullish markets
    } else if (this.currentMarketCondition.trend === "bearish") {
      multiplier *= 0.8 // Less liquidity in bearish markets
    }

    return baseLiquidity * multiplier
  }

  private calculateExecutionQuality(
    spread: number,
    buySlippage: number,
    sellSlippage: number,
    latency: number,
    profitable: boolean,
  ): number {
    // Base score
    let score = 50

    // Spread quality (higher spread is better)
    if (spread > 2.0) score += 15
    else if (spread > 1.5) score += 10
    else if (spread > 1.0) score += 5

    // Slippage quality (lower slippage is better)
    const totalSlippage = buySlippage + sellSlippage
    if (totalSlippage < 0.1) score += 15
    else if (totalSlippage < 0.2) score += 10
    else if (totalSlippage < 0.3) score += 5
    else if (totalSlippage > 0.5) score -= 10

    // Latency quality (lower latency is better)
    if (latency < 300) score += 15
    else if (latency < 500) score += 10
    else if (latency < 800) score += 5
    else if (latency > 1000) score -= 10

    // Profitability bonus
    if (profitable) score += 10
    else score -= 20

    // Ensure score is within 0-100 range
    return Math.max(0, Math.min(100, score))
  }

  // Ensure continuous trading by generating opportunities if none are found naturally
  public ensureContinuousTrading(): void {
    if (!this.isRunning) {
      return
    }

    // If we haven't had a trade in the last 10 seconds, generate one
    const lastTradeTime = this.arbitrageTrades.length > 0 ? this.arbitrageTrades[0].timestamp.getTime() : 0

    const currentTime = Date.now()
    const timeSinceLastTrade = currentTime - lastTradeTime

    if (timeSinceLastTrade > 10000) {
      // 10 seconds
      // Generate a synthetic opportunity
      const pairs = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
      const exchanges = ["Binance", "Bybit", "OKX"]

      const pair = pairs[Math.floor(Math.random() * pairs.length)]

      // Select random exchanges for buy and sell
      const buyExchangeIndex = Math.floor(Math.random() * exchanges.length)
      let sellExchangeIndex
      do {
        sellExchangeIndex = Math.floor(Math.random() * exchanges.length)
      } while (sellExchangeIndex === buyExchangeIndex)

      const buyExchange = exchanges[buyExchangeIndex]
      const sellExchange = exchanges[sellExchangeIndex]

      // Generate prices with a positive spread
      const basePrice =
        pair === "BTC/USDT"
          ? 30000 + Math.random() * 5000
          : pair === "ETH/USDT"
            ? 2000 + Math.random() * 500
            : 50 + Math.random() * 20 // SOL

      // Adjust spread based on market conditions
      let spreadMultiplier = 1.0
      if (this.currentMarketCondition.volatility === "high") spreadMultiplier *= 1.5
      if (this.currentMarketCondition.spreadWidth === "wide") spreadMultiplier *= 1.3
      if (this.currentMarketCondition.spreadWidth === "tight") spreadMultiplier *= 0.7

      const spread = (this.minSpread + Math.random() * 2) * spreadMultiplier
      const buyPrice = basePrice
      const sellPrice = buyPrice * (1 + spread / 100)

      const opportunity: ArbitrageOpportunity = {
        buyExchange,
        sellExchange,
        symbol: pair,
        buyPrice,
        sellPrice,
        spread,
        timestamp: new Date(),
      }

      // Execute the trade
      this.executeArbitrageTrade(opportunity)
    }
  }

  public subscribe(callback: (stats: SimulationStats) => void): () => void {
    this.listeners.push(callback)
    return () => {
      this.listeners = this.listeners.filter((listener) => listener !== callback)
    }
  }

  private notifyListeners(): void {
    const stats = this.getStats()
    this.listeners.forEach((listener) => listener(stats))
  }

  // Configure the win rate for future trades without pre-populating
  public manipulateWinRate(targetWinRate = 95): void {
    // Clear existing trades
    this.arbitrageTrades = []

    // Reset account balances
    this.accounts.forEach((account) => {
      account.balances = {
        USDT: this.initialInvestment / this.accounts.size, // Distribute initial investment across exchanges
        BTC: 0,
        ETH: 0,
        SOL: 0,
      }
      account.trades = []
    })

    // Reset volatility history
    this.volatilityHistory = []

    // Store the target win rate for future trades
    this.targetWinRate = targetWinRate

    this.notifyListeners()
  }
}

// Create a singleton instance
export const simulationEngine = new SimulationEngine()
