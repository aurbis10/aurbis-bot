"use client"

import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

// Create a single supabase client for the entire app
const supabaseClient = createClientComponentClient()

export default supabaseClient
