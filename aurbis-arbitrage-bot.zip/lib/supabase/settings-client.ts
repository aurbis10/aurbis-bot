import { createClient } from "@supabase/supabase-js"

// Initialize the Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ""

// Create a Supabase client with the service role key for server operations
export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey)

// Default settings
export const defaultSettings = {
  live: {
    autoTrading: false,
    continuous: false,
    minSpread: 1.3,
    tradeSize: 100,
    checkInterval: 3,
  },
  simulation: {
    autoTrading: false,
    continuous: false,
    minSpread: 1.3,
    tradeSize: 50,
    checkInterval: 3,
  },
}

// Special user ID for global settings
const GLOBAL_SETTINGS_ID = "00000000-0000-0000-0000-000000000000"

// Settings service
export const settingsService = {
  // Get settings for a specific user or global settings if userId is not provided
  async getUserSettings(userId?: string) {
    try {
      // If no userId is provided, fetch global settings
      const settingsId = userId || GLOBAL_SETTINGS_ID

      // Get settings from Supabase
      const { data, error } = await supabaseAdmin.from("user_settings").select("*").eq("user_id", settingsId).single()

      if (error) {
        console.error(`Error fetching settings for user ${settingsId}:`, error)

        // If no settings found, create default settings for this user
        if (error.code === "PGRST116") {
          if (userId) {
            // For a specific user, try to create default user settings
            await this.createUserSettings(userId)
            return defaultSettings
          } else {
            // For global settings, create the global defaults
            await this.createGlobalSettings()
            return defaultSettings
          }
        }

        return defaultSettings
      }

      // Convert from database format to application format
      return this.dbToAppSettings(data)
    } catch (error) {
      console.error(`Error in getUserSettings for user ${userId || "global"}:`, error)
      return defaultSettings
    }
  },

  // Alias for getGlobalSettings to maintain backward compatibility
  async getGlobalSettings() {
    return this.getUserSettings()
  },

  // Save settings for a specific user
  async saveUserSettings(settings: any, userId?: string) {
    try {
      // If no userId is provided, save as global settings
      const settingsId = userId || GLOBAL_SETTINGS_ID

      // Normalize settings
      const normalizedSettings = {
        live: {
          autoTrading: Boolean(settings.live?.autoTrading),
          continuous: Boolean(settings.live?.continuous),
          minSpread: Number(settings.live?.minSpread || defaultSettings.live.minSpread),
          tradeSize: Number(settings.live?.tradeSize || defaultSettings.live.tradeSize),
          checkInterval: Number(settings.live?.checkInterval || defaultSettings.live.checkInterval),
        },
        simulation: {
          autoTrading: Boolean(settings.simulation?.autoTrading),
          continuous: Boolean(settings.simulation?.continuous),
          minSpread: Number(settings.simulation?.minSpread || defaultSettings.simulation.minSpread),
          tradeSize: Number(settings.simulation?.tradeSize || defaultSettings.simulation.tradeSize),
          checkInterval: Number(settings.simulation?.checkInterval || defaultSettings.simulation.checkInterval),
        },
      }

      // Convert from application format to database format
      const dbSettings = this.appToDbSettings(normalizedSettings)

      // Check if settings exist for this user
      const { data, error: checkError } = await supabaseAdmin
        .from("user_settings")
        .select("user_id")
        .eq("user_id", settingsId)
        .single()

      if (checkError) {
        // Create settings if they don't exist
        const { error: insertError } = await supabaseAdmin.from("user_settings").insert({
          user_id: settingsId,
          ...dbSettings,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })

        if (insertError) {
          console.error(`Error creating settings for user ${settingsId}:`, insertError)
          return false
        }
      } else {
        // Update existing settings
        const { error: updateError } = await supabaseAdmin
          .from("user_settings")
          .update({
            ...dbSettings,
            updated_at: new Date().toISOString(),
          })
          .eq("user_id", settingsId)

        if (updateError) {
          console.error(`Error updating settings for user ${settingsId}:`, updateError)
          return false
        }
      }

      return true
    } catch (error) {
      console.error(`Error in saveUserSettings for user ${userId || "global"}:`, error)
      return false
    }
  },

  // Alias for saveGlobalSettings to maintain backward compatibility
  async saveGlobalSettings(settings: any) {
    return this.saveUserSettings(settings)
  },

  // Create user-specific settings (copying from global settings if they exist)
  async createUserSettings(userId: string) {
    try {
      // First, try to get global settings to copy from
      const globalSettings = await this.getGlobalSettings()

      // Convert to DB format
      const dbSettings = this.appToDbSettings(globalSettings)

      // Insert new user settings
      const { error } = await supabaseAdmin.from("user_settings").insert({
        user_id: userId,
        ...dbSettings,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (error) {
        console.error(`Error creating settings for user ${userId}:`, error)
        return false
      }

      return true
    } catch (error) {
      console.error(`Error in createUserSettings for user ${userId}:`, error)
      return false
    }
  },

  // Create default global settings
  async createGlobalSettings() {
    try {
      const dbSettings = this.appToDbSettings(defaultSettings)

      const { error } = await supabaseAdmin.from("user_settings").insert({
        user_id: GLOBAL_SETTINGS_ID,
        ...dbSettings,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      })

      if (error) {
        console.error("Error creating default global settings:", error)
        return false
      }

      return true
    } catch (error) {
      console.error("Error in createGlobalSettings:", error)
      return false
    }
  },

  // Reset user settings to global defaults
  async resetUserSettings(userId: string) {
    try {
      // First, get global settings
      const globalSettings = await this.getGlobalSettings()

      // Save those settings for the user
      return await this.saveUserSettings(globalSettings, userId)
    } catch (error) {
      console.error(`Error in resetUserSettings for user ${userId}:`, error)
      return false
    }
  },

  // Convert from database format to application format
  dbToAppSettings(dbSettings: any) {
    return {
      live: {
        autoTrading: dbSettings.auto_trade || false,
        continuous: dbSettings.auto_trade || false, // Using auto_trade as a proxy for continuous
        minSpread: Number(dbSettings.min_spread) || defaultSettings.live.minSpread,
        tradeSize: Number(dbSettings.trade_size) || defaultSettings.live.tradeSize,
        checkInterval: dbSettings.check_interval || defaultSettings.live.checkInterval,
      },
      simulation: {
        autoTrading: dbSettings.auto_trade || false,
        continuous: dbSettings.auto_trade || false,
        minSpread: Number(dbSettings.min_spread) || defaultSettings.simulation.minSpread,
        tradeSize: Number(dbSettings.trade_size) || defaultSettings.simulation.tradeSize,
        checkInterval: dbSettings.check_interval || defaultSettings.simulation.checkInterval,
      },
    }
  },

  // Convert from application format to database format
  appToDbSettings(appSettings: any) {
    // Use live settings as the primary settings for the database
    return {
      auto_trade: appSettings.live.autoTrading,
      min_spread: appSettings.live.minSpread,
      trade_size: appSettings.live.tradeSize,
      check_interval: appSettings.live.checkInterval,
      notification_email: false, // Default values for notification settings
      notification_app: false,
    }
  },
}
