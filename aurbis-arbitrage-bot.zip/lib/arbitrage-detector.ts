import type { PriceData, ArbitrageOpportunity, Exchange } from "@/lib/types"
// Import the notification service at the top of the file
import { notificationService } from "@/lib/notification"

export class ArbitrageDetector {
  private minSpread: number
  private exchanges: Map<string, Exchange>
  private tradingPairs: string[]
  private fees: Map<string, number>

  constructor(exchanges: Map<string, Exchange>, tradingPairs: string[], minSpread = 1.3) {
    this.exchanges = exchanges
    this.tradingPairs = tradingPairs
    this.minSpread = minSpread

    // Set default fees for each exchange (in percentage)
    this.fees = new Map<string, number>()
    this.fees.set("Binance", 0.1)
    this.fees.set("Bybit", 0.1)
    this.fees.set("OKX", 0.1)
  }

  async detectOpportunities(): Promise<ArbitrageOpportunity[]> {
    const opportunities: ArbitrageOpportunity[] = []

    for (const pair of this.tradingPairs) {
      const prices: PriceData[] = []

      // Get prices from all exchanges
      for (const [name, exchange] of this.exchanges.entries()) {
        try {
          const price = await exchange.getPrice(pair)
          prices.push(price)
        } catch (error) {
          console.error(`Failed to get ${pair} price from ${name}:`, error)
        }
      }

      // Find arbitrage opportunities
      for (let i = 0; i < prices.length; i++) {
        for (let j = 0; j < prices.length; j++) {
          if (i === j) continue

          const buyExchange = prices[i].exchange
          const sellExchange = prices[j].exchange
          const buyPrice = prices[i].ask // We buy at the ask price
          const sellPrice = prices[j].bid // We sell at the bid price

          // Calculate fees
          const buyFee = this.fees.get(buyExchange) || 0.1
          const sellFee = this.fees.get(sellExchange) || 0.1

          // Calculate the spread after fees
          const buyPriceWithFee = buyPrice * (1 + buyFee / 100)
          const sellPriceWithFee = sellPrice * (1 - sellFee / 100)
          const spread = (sellPriceWithFee / buyPriceWithFee - 1) * 100

          // Check if the spread is above the minimum threshold
          if (spread >= this.minSpread) {
            opportunities.push({
              buyExchange,
              sellExchange,
              symbol: pair,
              buyPrice,
              sellPrice,
              spread,
              timestamp: new Date(),
            })

            // Add notification for significant opportunities
            if (spread >= this.minSpread * 1.5) {
              notificationService.success(
                `High profit opportunity: ${pair} - Buy on ${buyExchange} at $${buyPrice.toFixed(2)}, Sell on ${sellExchange} at $${sellPrice.toFixed(2)} (${spread.toFixed(2)}% spread)`,
              )
            }
          }
        }
      }
    }

    return opportunities
  }

  setMinSpread(minSpread: number): void {
    this.minSpread = minSpread
  }
}
