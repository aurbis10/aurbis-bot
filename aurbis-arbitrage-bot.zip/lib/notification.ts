type NotificationType = "info" | "success" | "warning" | "error"

interface Notification {
  type: NotificationType
  message: string
  timestamp: Date
}

class NotificationService {
  private notifications: Notification[] = []
  private maxNotifications = 100
  private subscribers: ((notification: Notification) => void)[] = []

  addNotification(type: NotificationType, message: string): Notification {
    const notification: Notification = {
      type,
      message,
      timestamp: new Date(),
    }

    this.notifications.unshift(notification)

    // Trim the notifications array if it exceeds the maximum length
    if (this.notifications.length > this.maxNotifications) {
      this.notifications = this.notifications.slice(0, this.maxNotifications)
    }

    // Notify all subscribers
    this.subscribers.forEach((subscriber) => subscriber(notification))

    return notification
  }

  getNotifications(): Notification[] {
    return [...this.notifications]
  }

  subscribe(callback: (notification: Notification) => void): () => void {
    this.subscribers.push(callback)

    // Return unsubscribe function
    return () => {
      this.subscribers = this.subscribers.filter((sub) => sub !== callback)
    }
  }

  // Helper methods for different notification types
  info(message: string): Notification {
    return this.addNotification("info", message)
  }

  success(message: string): Notification {
    return this.addNotification("success", message)
  }

  warning(message: string): Notification {
    return this.addNotification("warning", message)
  }

  error(message: string): Notification {
    return this.addNotification("error", message)
  }
}

// Create a singleton instance
export const notificationService = new NotificationService()
