"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import supabaseClient from "@/lib/supabase/client"
import type { User } from "@supabase/supabase-js"

type AuthContextType = {
  user: User | null
  loading: boolean
  signUp: (email: string, password: string, username: string) => Promise<{ error: any; success: boolean }>
  signIn: (email: string, password: string) => Promise<{ error: any; success: boolean }>
  signOut: () => Promise<void>
  verifyEmail: (email: string, code: string) => Promise<{ error: any; success: boolean }>
  sendVerificationCode: (email: string) => Promise<{ error: any; success: boolean }>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: false,
  signUp: async () => ({ error: null, success: false }),
  signIn: async () => ({ error: null, success: false }),
  signOut: async () => {},
  verifyEmail: async () => ({ error: null, success: false }),
  sendVerificationCode: async () => ({ error: null, success: false }),
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const setData = async () => {
      try {
        const {
          data: { session },
          error,
        } = await supabaseClient.auth.getSession()

        if (error) {
          console.error(error)
          setLoading(false)
          return
        }

        if (session?.user) {
          setUser(session.user)
        }
      } catch (err) {
        console.error("Error getting session:", err)
      } finally {
        setLoading(false)
      }
    }

    setData()

    const { data: authListener } = supabaseClient.auth.onAuthStateChange(async (event, session) => {
      if (session?.user) {
        setUser(session.user)
      } else {
        setUser(null)
      }
      setLoading(false)
    })

    return () => {
      authListener?.subscription.unsubscribe()
    }
  }, [])

  const signUp = async (email: string, password: string, username: string) => {
    setLoading(true)

    try {
      const formData = new FormData()
      formData.append("email", email)
      formData.append("password", password)
      formData.append("username", username)

      const response = await fetch("/api/auth/signup", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (!result.success) {
        return { error: result.error, success: false }
      }

      router.push(`/auth/verify-email?email=${encodeURIComponent(email)}`)
      return { error: null, success: true }
    } catch (error) {
      console.error("Sign up error:", error)
      return { error: "An unexpected error occurred", success: false }
    } finally {
      setLoading(false)
    }
  }

  const signIn = async (email: string, password: string) => {
    setLoading(true)
    try {
      const { error } = await supabaseClient.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        return { error: error.message, success: false }
      }

      router.push("/")
      return { error: null, success: true }
    } catch (error) {
      console.error("Sign in error:", error)
      return { error: "An unexpected error occurred", success: false }
    } finally {
      setLoading(false)
    }
  }

  const signOut = async () => {
    try {
      await supabaseClient.auth.signOut()
      router.push("/auth/login")
    } catch (error) {
      console.error("Sign out error:", error)
    }
  }

  const sendVerificationCode = async (email: string) => {
    try {
      const response = await fetch("/api/auth/resend-code", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      })

      const result = await response.json()

      if (!result.success) {
        return { error: result.error, success: false }
      }

      return { error: null, success: true }
    } catch (error) {
      console.error("Error sending verification code:", error)
      return { error: "An unexpected error occurred", success: false }
    }
  }

  const verifyEmail = async (email: string, code: string) => {
    try {
      const response = await fetch("/api/auth/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, code }),
      })

      const result = await response.json()

      if (!result.success) {
        return { error: result.error, success: false }
      }

      router.push("/auth/login?verified=true")
      return { error: null, success: true }
    } catch (error) {
      console.error("Verification error:", error)
      return { error: "An unexpected error occurred", success: false }
    }
  }

  const value = {
    user,
    loading,
    signUp,
    signIn,
    signOut,
    verifyEmail,
    sendVerificationCode,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  return context
}
