import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Settings, PlayCircle, Shield } from "lucide-react"
import Link from "next/link"
import { BotStatus } from "@/components/bot-status"
import { ArbitrageOpportunities } from "@/components/arbitrage-opportunities"
import { RecentTrades } from "@/components/recent-trades"
import { ExchangeStatus } from "@/components/exchange-status"
import { Notifications } from "@/components/notifications"
import { UserProfile } from "@/components/user-profile"

export default function Home() {
  return (
    <main className="container mx-auto p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Aurbis Arbitrage</h1>
        <div className="flex items-center gap-2">
          <Notifications />
          <Link href="/simulation">
            <Button variant="outline" size="sm">
              <PlayCircle className="h-4 w-4 mr-2" />
              Simulation
            </Button>
          </Link>
          <Link href="/admin">
            <Button variant="outline" size="sm">
              <Shield className="h-4 w-4 mr-2" />
              Admin
            </Button>
          </Link>
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Link href="/logs">
            <Button variant="outline" size="sm">
              Logs
            </Button>
          </Link>
          <UserProfile />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <BotStatus />
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Trading Pairs</CardTitle>
            <CardDescription>Monitored cryptocurrency pairs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between items-center p-2 bg-muted/50 rounded-md">
                <span className="font-medium">BTC/USDT</span>
                <span className="text-green-500">Active</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-muted/50 rounded-md">
                <span className="font-medium">ETH/USDT</span>
                <span className="text-green-500">Active</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-muted/50 rounded-md">
                <span className="font-medium">SOL/USDT</span>
                <span className="text-green-500">Active</span>
              </div>
            </div>
          </CardContent>
        </Card>
        <ExchangeStatus />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ArbitrageOpportunities />
        <RecentTrades />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Configuration</CardTitle>
          <CardDescription>Adjust arbitrage parameters</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Minimum Spread (%)</label>
              <div className="flex items-center">
                <input type="range" min="0.5" max="3.0" step="0.1" defaultValue="1.3" className="w-full" />
                <span className="ml-2 min-w-[40px] text-right">1.3%</span>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Trade Size (USDT)</label>
              <input type="number" defaultValue="100" className="w-full p-2 border rounded-md" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Price Check Interval (seconds)</label>
              <input type="number" defaultValue="3" min="1" max="60" className="w-full p-2 border rounded-md" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Auto-Trade</label>
              <div className="flex items-center space-x-2">
                <input type="checkbox" id="auto-trade" defaultChecked />
                <label htmlFor="auto-trade">Enable automatic trading</label>
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-end space-x-2">
          <Button variant="outline">Reset to Defaults</Button>
          <Button>Save Configuration</Button>
        </CardFooter>
      </Card>
    </main>
  )
}
