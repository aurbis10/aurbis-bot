import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Download, RefreshCw, Filter } from "lucide-react"
import Link from "next/link"

export default function LogsPage() {
  // Sample log data
  const logs = [
    { id: 1, type: "info", message: "Bot started", timestamp: "2023-05-14T14:22:10" },
    { id: 2, type: "info", message: "Connected to Binance WebSocket", timestamp: "2023-05-14T14:22:12" },
    { id: 3, type: "info", message: "Connected to Bybit WebSocket", timestamp: "2023-05-14T14:22:13" },
    { id: 4, type: "info", message: "Connected to OKX WebSocket", timestamp: "2023-05-14T14:22:14" },
    { id: 5, type: "info", message: "Scanning for arbitrage opportunities", timestamp: "2023-05-14T14:22:20" },
    { id: 6, type: "warning", message: "Bybit API rate limit approaching", timestamp: "2023-05-14T14:23:45" },
    {
      id: 7,
      type: "success",
      message: "Arbitrage opportunity found: BTC/USDT (Binance → OKX, 1.4%)",
      timestamp: "2023-05-14T14:24:10",
    },
    { id: 8, type: "info", message: "Executing trade: Buy 0.05 BTC on Binance", timestamp: "2023-05-14T14:24:11" },
    { id: 9, type: "info", message: "Executing trade: Sell 0.05 BTC on OKX", timestamp: "2023-05-14T14:24:12" },
    { id: 10, type: "success", message: "Trade completed: Profit $32.45", timestamp: "2023-05-14T14:24:15" },
    { id: 11, type: "error", message: "Failed to connect to Bybit API: Timeout", timestamp: "2023-05-14T14:25:30" },
    { id: 12, type: "info", message: "Retrying Bybit connection...", timestamp: "2023-05-14T14:25:35" },
    { id: 13, type: "info", message: "Connected to Bybit WebSocket", timestamp: "2023-05-14T14:25:40" },
    {
      id: 14,
      type: "warning",
      message: "Insufficient balance on OKX for ETH/USDT trade",
      timestamp: "2023-05-14T14:26:15",
    },
    { id: 15, type: "info", message: "Scanning for arbitrage opportunities", timestamp: "2023-05-14T14:27:20" },
  ]

  return (
    <main className="container mx-auto p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Aurbis Arbitrage Logs</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Link href="/">
            <Button size="sm">Back to Dashboard</Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>System Logs</CardTitle>
          <CardDescription>Activity, trades, and errors</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {logs.map((log) => (
              <div key={log.id} className="flex items-start p-2 border-b last:border-0">
                <Badge
                  variant={
                    log.type === "error"
                      ? "destructive"
                      : log.type === "warning"
                        ? "warning"
                        : log.type === "success"
                          ? "success"
                          : "secondary"
                  }
                  className="mr-3 mt-1"
                >
                  {log.type}
                </Badge>
                <div className="flex-1">
                  <p>{log.message}</p>
                  <p className="text-xs text-gray-500">{new Date(log.timestamp).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </main>
  )
}
