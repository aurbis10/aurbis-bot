import Link from "next/link"
import { Button } from "@/components/ui/button"
import { SimulationControl } from "@/components/simulation/simulation-control"
import { ExchangeBalances } from "@/components/simulation/exchange-balances"
import { SimulationStatistics } from "@/components/simulation/simulation-stats"
import { MarketPrices } from "@/components/simulation/market-prices"
import { SimulatedTrades } from "@/components/simulation/simulated-trades"
import { ProfitChart } from "@/components/simulation/profit-chart"
import { SimulationDisclaimer } from "@/components/simulation/simulation-disclaimer"
import { ArrowLeft } from "lucide-react"

export default function SimulationPage() {
  return (
    <main className="container mx-auto p-4 space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mr-2">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">Aurbis Arbitrage Simulation</h1>
        </div>
      </div>

      <SimulationDisclaimer />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <SimulationControl />
        <ExchangeBalances />
        <div className="md:col-span-1">
          <SimulationStatistics />
        </div>
      </div>

      <ProfitChart />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SimulatedTrades />
        <MarketPrices />
      </div>
    </main>
  )
}
