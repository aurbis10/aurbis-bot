import { NextResponse } from "next/server"
import type { BotConfig } from "@/lib/types"

// Default configuration
const config: BotConfig = {
  minSpread: 1.3,
  tradeSize: 100,
  checkInterval: 3,
  autoTrade: true,
  tradingPairs: ["BTC/USDT", "ETH/USDT", "SOL/USDT"],
}

export async function GET() {
  return NextResponse.json({ success: true, config })
}

export async function POST(request: Request) {
  try {
    const newConfig = await request.json()

    // Validate the new configuration
    if (typeof newConfig.minSpread === "number" && newConfig.minSpread > 0) {
      config.minSpread = newConfig.minSpread
    }

    if (typeof newConfig.tradeSize === "number" && newConfig.tradeSize > 0) {
      config.tradeSize = newConfig.tradeSize
    }

    if (typeof newConfig.checkInterval === "number" && newConfig.checkInterval > 0) {
      config.checkInterval = newConfig.checkInterval
    }

    if (typeof newConfig.autoTrade === "boolean") {
      config.autoTrade = newConfig.autoTrade
    }

    if (Array.isArray(newConfig.tradingPairs) && newConfig.tradingPairs.length > 0) {
      config.tradingPairs = newConfig.tradingPairs
    }

    return NextResponse.json({ success: true, config })
  } catch (error) {
    console.error("Failed to update configuration:", error)
    return NextResponse.json(
      { success: false, message: "Failed to update configuration", error: String(error) },
      { status: 500 },
    )
  }
}
