import { NextResponse } from "next/server"

// Reference to the global state
let isRunning = false
let intervalId: NodeJS.Timeout | null = null
const exchanges = new Map()

export async function POST() {
  try {
    if (!isRunning) {
      return NextResponse.json({ success: false, message: "Bot is not running" })
    }

    // Stop the interval
    if (intervalId) {
      clearInterval(intervalId)
      intervalId = null
    }

    // Disconnect from exchanges
    for (const [_, exchange] of exchanges.entries()) {
      exchange.disconnect()
    }

    // Clear the exchanges map
    exchanges.clear()

    // Update state
    isRunning = false

    return NextResponse.json({ success: true, message: "Bot stopped successfully" })
  } catch (error) {
    console.error("Failed to stop bot:", error)
    return NextResponse.json({ success: false, message: "Failed to stop bot", error: String(error) }, { status: 500 })
  }
}
