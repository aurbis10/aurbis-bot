import { NextResponse } from "next/server"

// Reference to the global state
const isRunning = false

export async function GET() {
  return NextResponse.json({
    success: true,
    status: {
      running: isRunning,
      lastScan: isRunning ? new Date().toISOString() : null,
    },
  })
}
