import { NextResponse } from "next/server"
import { settingsService } from "@/lib/supabase/settings-client"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

// Helper function to get the current user from the session
async function getCurrentUser(req) {
  const cookieStore = cookies()

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || "",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
    {
      cookies: {
        get(name) {
          return cookieStore.get(name)?.value
        },
      },
    },
  )

  const {
    data: { session },
  } = await supabase.auth.getSession()
  return session?.user || null
}

export async function GET(req) {
  try {
    console.log("Loading simulation settings")

    // Get current user from the session
    const user = await getCurrentUser(req)

    // Get user-specific settings if user is logged in, otherwise get global settings
    const settings = user ? await settingsService.getUserSettings(user.id) : await settingsService.getGlobalSettings()

    return NextResponse.json({
      success: true,
      settings: settings.simulation,
      isUserSettings: !!user,
    })
  } catch (error) {
    console.error("Error in GET /api/simulation/settings:", error)
    return NextResponse.json(
      {
        success: false,
        error: `Failed to load simulation settings: ${error instanceof Error ? error.message : "Unknown error"}`,
      },
      { status: 500 },
    )
  }
}

export async function POST(req) {
  try {
    console.log("Saving simulation settings")

    // Get current user from the session
    const user = await getCurrentUser(req)

    // Parse request body
    let body
    try {
      body = await req.json()
    } catch (parseError) {
      console.error("Error parsing request body:", parseError)
      return NextResponse.json(
        {
          success: false,
          error: "Invalid JSON in request body",
        },
        { status: 400 },
      )
    }

    // Check if settings are provided
    if (!body || !body.settings) {
      return NextResponse.json(
        {
          success: false,
          error: "No simulation settings provided",
        },
        { status: 400 },
      )
    }

    const simulationSettings = body.settings

    // Load current settings
    const currentSettings = user
      ? await settingsService.getUserSettings(user.id)
      : await settingsService.getGlobalSettings()

    // Update only the simulation settings
    const updatedSettings = {
      ...currentSettings,
      simulation: {
        ...currentSettings.simulation,
        ...simulationSettings,
      },
    }

    // Save the updated settings
    const saved = user
      ? await settingsService.saveUserSettings(updatedSettings, user.id)
      : await settingsService.saveGlobalSettings(updatedSettings)

    if (!saved) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to save simulation settings",
        },
        { status: 500 },
      )
    }

    // Load and return the saved settings
    const settings = user ? await settingsService.getUserSettings(user.id) : await settingsService.getGlobalSettings()

    return NextResponse.json({
      success: true,
      settings: settings.simulation,
      isUserSettings: !!user,
    })
  } catch (error) {
    console.error("Error in POST /api/simulation/settings:", error)
    return NextResponse.json(
      {
        success: false,
        error: `Failed to save simulation settings: ${error instanceof Error ? error.message : "Unknown error"}`,
      },
      { status: 500 },
    )
  }
}
