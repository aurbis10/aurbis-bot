import { NextResponse } from "next/server"
import { settingsService } from "@/lib/supabase/settings-client"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

// Helper function to get the current user from the session
async function getCurrentUser() {
  const cookieStore = cookies()

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || "",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
    {
      cookies: {
        get(name) {
          return cookieStore.get(name)?.value
        },
      },
    },
  )

  const {
    data: { session },
  } = await supabase.auth.getSession()
  return session?.user || null
}

export async function POST() {
  try {
    // Get current user from the session
    const user = await getCurrentUser()

    // Only logged-in users can reset their settings
    if (!user) {
      return NextResponse.json(
        {
          success: false,
          error: "Not authenticated. Cannot reset settings.",
        },
        { status: 401 },
      )
    }

    // Reset user's settings to global defaults
    const reset = await settingsService.resetUserSettings(user.id)

    if (!reset) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to reset settings to defaults",
        },
        { status: 500 },
      )
    }

    // Load and return the new settings (should match global defaults)
    const settings = await settingsService.getUserSettings(user.id)

    return NextResponse.json({
      success: true,
      settings,
      message: "Settings reset to global defaults",
    })
  } catch (error) {
    console.error("Error in POST /api/admin/settings/reset:", error)
    return NextResponse.json(
      {
        success: false,
        error: `Failed to reset settings: ${error instanceof Error ? error.message : "Unknown error"}`,
      },
      { status: 500 },
    )
  }
}
