import { NextResponse } from "next/server"
import { settingsService } from "@/lib/supabase/settings-client"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

// Helper function to get the current user from the session
async function getCurrentUser() {
  const cookieStore = cookies()

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || "",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
    {
      cookies: {
        get(name) {
          return cookieStore.get(name)?.value
        },
      },
    },
  )

  const {
    data: { session },
  } = await supabase.auth.getSession()
  return session?.user || null
}

export async function POST(request, { params }) {
  try {
    console.log(`Saving settings for tab: ${params.tab}`)

    // Get current user from the session
    const user = await getCurrentUser()

    // Validate tab parameter
    if (params.tab !== "live" && params.tab !== "simulation") {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid tab parameter. Must be 'live' or 'simulation'",
        },
        { status: 400 },
      )
    }

    // Parse request body
    let body
    try {
      body = await request.json()
    } catch (parseError) {
      console.error("Error parsing request body:", parseError)
      return NextResponse.json(
        {
          success: false,
          error: "Invalid JSON in request body",
        },
        { status: 400 },
      )
    }

    // Check if settings are provided
    if (!body || !body.settings) {
      return NextResponse.json(
        {
          success: false,
          error: "No settings provided in request",
        },
        { status: 400 },
      )
    }

    // Load current settings (user-specific or global)
    const currentSettings = user
      ? await settingsService.getUserSettings(user.id)
      : await settingsService.getGlobalSettings()

    // Update only the specified tab settings
    const tabSettings = body.settings[params.tab]

    if (!tabSettings) {
      return NextResponse.json(
        {
          success: false,
          error: `Tab ${params.tab} not found in provided settings`,
        },
        { status: 400 },
      )
    }

    // Update the settings
    const updatedSettings = {
      ...currentSettings,
      [params.tab]: {
        ...currentSettings[params.tab],
        ...tabSettings,
      },
    }

    // Save the updated settings (user-specific or global)
    const saved = user
      ? await settingsService.saveUserSettings(updatedSettings, user.id)
      : await settingsService.saveGlobalSettings(updatedSettings)

    if (!saved) {
      return NextResponse.json(
        {
          success: false,
          error: `Failed to save ${params.tab} settings`,
        },
        { status: 500 },
      )
    }

    // Load and return the saved settings
    const settings = user ? await settingsService.getUserSettings(user.id) : await settingsService.getGlobalSettings()

    return NextResponse.json({
      success: true,
      settings,
      isUserSettings: !!user,
      message: `${params.tab} settings saved successfully`,
    })
  } catch (error) {
    console.error(`Error in POST /api/admin/settings/${params.tab}:`, error)
    return NextResponse.json(
      {
        success: false,
        error: `Failed to save ${params.tab} settings: ${error instanceof Error ? error.message : "Unknown error"}`,
      },
      { status: 500 },
    )
  }
}
