import { NextResponse } from "next/server"
import { settingsService } from "@/lib/supabase/settings-client"
import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

// Helper function to get the current user from the session
async function getCurrentUser(req) {
  const cookieStore = cookies()

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || "",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "",
    {
      cookies: {
        get(name) {
          return cookieStore.get(name)?.value
        },
      },
    },
  )

  const {
    data: { session },
  } = await supabase.auth.getSession()
  return session?.user || null
}

export async function GET(req) {
  try {
    console.log("Loading settings from database")

    // Get current user from the session
    const user = await getCurrentUser(req)

    // Get user-specific settings if user is logged in, otherwise get global settings
    const settings = user ? await settingsService.getUserSettings(user.id) : await settingsService.getGlobalSettings()

    console.log(`Settings loaded successfully for ${user ? "user " + user.id : "global"}:`, settings)
    return NextResponse.json({
      success: true,
      settings,
      isUserSettings: !!user,
    })
  } catch (error) {
    console.error("Error in GET /api/admin/settings:", error)
    return NextResponse.json(
      {
        success: false,
        error: `Failed to load settings: ${error instanceof Error ? error.message : "Unknown error"}`,
      },
      { status: 500 },
    )
  }
}

export async function POST(req) {
  try {
    console.log("Saving settings to database")

    // Get current user from the session
    const user = await getCurrentUser(req)

    // Parse request body
    let body
    try {
      body = await req.json()
    } catch (parseError) {
      console.error("Error parsing request body:", parseError)
      return NextResponse.json(
        {
          success: false,
          error: "Invalid JSON in request body",
        },
        { status: 400 },
      )
    }

    // Check if settings are provided
    if (!body || !body.settings) {
      return NextResponse.json(
        {
          success: false,
          error: "No settings provided in request",
        },
        { status: 400 },
      )
    }

    console.log(`Settings to save for ${user ? "user " + user.id : "global"}:`, body.settings)

    // Save settings for the user if logged in, otherwise save as global settings
    const saved = user
      ? await settingsService.saveUserSettings(body.settings, user.id)
      : await settingsService.saveGlobalSettings(body.settings)

    if (!saved) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to save settings",
        },
        { status: 500 },
      )
    }

    // Load and return the saved settings
    const settings = user ? await settingsService.getUserSettings(user.id) : await settingsService.getGlobalSettings()

    return NextResponse.json({
      success: true,
      settings,
      isUserSettings: !!user,
    })
  } catch (error) {
    console.error("Error in POST /api/admin/settings:", error)
    return NextResponse.json(
      {
        success: false,
        error: `Failed to save settings: ${error instanceof Error ? error.message : "Unknown error"}`,
      },
      { status: 500 },
    )
  }
}
