"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, AlertTriangle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { SystemMonitor } from "@/components/admin/system-monitor"

export default function AdminPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saveLoading, setSaveLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Settings state
  const [settings, setSettings] = useState({
    live: {
      autoTrading: false,
      continuous: false,
      minSpread: 1.3,
      tradeSize: 100,
      checkInterval: 3,
    },
    simulation: {
      autoTrading: false,
      continuous: false,
      minSpread: 1.3,
      tradeSize: 50,
      checkInterval: 3,
    },
  })

  // Fetch current settings on page load
  useEffect(() => {
    async function fetchSettings() {
      try {
        const response = await fetch("/api/admin/settings")
        if (!response.ok) {
          throw new Error("Failed to fetch settings")
        }
        const data = await response.json()
        if (data.success) {
          setSettings(data.settings)
        } else {
          setError(data.error || "Failed to load settings")
        }
      } catch (err) {
        console.error("Error fetching settings:", err)
        setError("Failed to load settings. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchSettings()
  }, [])

  // Save settings
  const saveSettings = async () => {
    setSaveLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ settings }),
      })

      const data = await response.json()
      if (data.success) {
        setSuccess("Settings saved successfully")
      } else {
        setError(data.error || "Failed to save settings")
      }
    } catch (err) {
      console.error("Error saving settings:", err)
      setError("Failed to save settings. Please try again.")
    } finally {
      setSaveLoading(false)
    }
  }

  // Toggle auto-trading for live mode
  const toggleLiveAutoTrading = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      live: {
        ...prev.live,
        autoTrading: value,
      },
    }))
  }

  // Toggle continuous operation for live mode
  const toggleLiveContinuous = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      live: {
        ...prev.live,
        continuous: value,
      },
    }))
  }

  // Toggle auto-trading for simulation mode
  const toggleSimulationAutoTrading = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      simulation: {
        ...prev.simulation,
        autoTrading: value,
      },
    }))
  }

  // Toggle continuous operation for simulation mode
  const toggleSimulationContinuous = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      simulation: {
        ...prev.simulation,
        continuous: value,
      },
    }))
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  return (
    <main className="container mx-auto p-4 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <div className="space-x-2">
          <Link href="/">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 border-green-200 text-green-800">
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <SystemMonitor />

      <Tabs defaultValue="live">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="live">Live Trading</TabsTrigger>
          <TabsTrigger value="simulation">Simulation</TabsTrigger>
        </TabsList>

        <TabsContent value="live">
          <Card>
            <CardHeader>
              <CardTitle>Live Trading Settings</CardTitle>
              <CardDescription>Configure how the arbitrage bot will operate in live trading mode</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="live-autoTrading" className="text-base">
                      Auto Trading
                    </Label>
                    <p className="text-sm text-gray-500">
                      Automatically execute trades when opportunities are detected
                    </p>
                  </div>
                  <Switch
                    id="live-autoTrading"
                    checked={settings.live.autoTrading}
                    onCheckedChange={toggleLiveAutoTrading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="live-continuous" className="text-base">
                      24/7 Operation
                    </Label>
                    <p className="text-sm text-gray-500">Run continuously looking for arbitrage opportunities</p>
                  </div>
                  <Switch
                    id="live-continuous"
                    checked={settings.live.continuous}
                    onCheckedChange={toggleLiveContinuous}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="live-minSpread">Minimum Spread (%)</Label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      id="live-minSpread"
                      min="0.5"
                      max="5.0"
                      step="0.1"
                      value={settings.live.minSpread}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          live: {
                            ...settings.live,
                            minSpread: Number.parseFloat(e.target.value),
                          },
                        })
                      }
                      className="w-full"
                    />
                    <span className="ml-2 min-w-[40px] text-right">{settings.live.minSpread}%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="live-tradeSize">Trade Size (USDT)</Label>
                  <input
                    type="number"
                    id="live-tradeSize"
                    value={settings.live.tradeSize}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        live: {
                          ...settings.live,
                          tradeSize: Number.parseInt(e.target.value),
                        },
                      })
                    }
                    className="w-full p-2 border rounded-md"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="live-checkInterval">Check Interval (seconds)</Label>
                  <input
                    type="number"
                    id="live-checkInterval"
                    value={settings.live.checkInterval}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        live: {
                          ...settings.live,
                          checkInterval: Number.parseInt(e.target.value),
                        },
                      })
                    }
                    min="1"
                    max="60"
                    className="w-full p-2 border rounded-md"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveSettings} disabled={saveLoading} className="ml-auto">
                {saveLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Save Live Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="simulation">
          <Card>
            <CardHeader>
              <CardTitle>Simulation Settings</CardTitle>
              <CardDescription>Configure how the simulation mode will operate</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sim-autoTrading" className="text-base">
                      Auto Trading
                    </Label>
                    <p className="text-sm text-gray-500">
                      Automatically execute simulated trades when opportunities are detected
                    </p>
                  </div>
                  <Switch
                    id="sim-autoTrading"
                    checked={settings.simulation.autoTrading}
                    onCheckedChange={toggleSimulationAutoTrading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sim-continuous" className="text-base">
                      24/7 Operation
                    </Label>
                    <p className="text-sm text-gray-500">Run simulation continuously</p>
                  </div>
                  <Switch
                    id="sim-continuous"
                    checked={settings.simulation.continuous}
                    onCheckedChange={toggleSimulationContinuous}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sim-minSpread">Minimum Spread (%)</Label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      id="sim-minSpread"
                      min="0.5"
                      max="5.0"
                      step="0.1"
                      value={settings.simulation.minSpread}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          simulation: {
                            ...settings.simulation,
                            minSpread: Number.parseFloat(e.target.value),
                          },
                        })
                      }
                      className="w-full"
                    />
                    <span className="ml-2 min-w-[40px] text-right">{settings.simulation.minSpread}%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sim-tradeSize">Trade Size (USDT)</Label>
                  <input
                    type="number"
                    id="sim-tradeSize"
                    value={settings.simulation.tradeSize}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        simulation: {
                          ...settings.simulation,
                          tradeSize: Number.parseInt(e.target.value),
                        },
                      })
                    }
                    className="w-full p-2 border rounded-md"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sim-checkInterval">Check Interval (seconds)</Label>
                  <input
                    type="number"
                    id="sim-checkInterval"
                    value={settings.simulation.checkInterval}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        simulation: {
                          ...settings.simulation,
                          checkInterval: Number.parseInt(e.target.value),
                        },
                      })
                    }
                    min="1"
                    max="60"
                    className="w-full p-2 border rounded-md"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveSettings} disabled={saveLoading} className="ml-auto">
                {saveLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Save Simulation Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </main>
  )
}
