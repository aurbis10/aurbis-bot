import { NextResponse } from "next/server"
import {
  startLiveTrading,
  stopLiveTrading,
  startSimulation,
  stopSimulation,
  syncProcessesWithSettings,
} from "@/lib/background-service"
import path from "path"
import fs from "fs"

// Path to the status file
const statusFilePath = path.join(process.cwd(), "data", "status.json")

// Load status
const loadStatus = () => {
  if (!fs.existsSync(statusFilePath)) {
    return {
      live: {
        running: false,
        lastStart: null,
        lastCheck: null,
        errors: [],
      },
      simulation: {
        running: false,
        lastStart: null,
        lastCheck: null,
        errors: [],
      },
    }
  }

  try {
    const statusData = fs.readFileSync(statusFilePath, "utf8")
    return JSON.parse(statusData)
  } catch (error) {
    console.error("Error reading status file:", error)
    return {
      live: { running: false, lastStart: null, lastCheck: null, errors: [] },
      simulation: { running: false, lastStart: null, lastCheck: null, errors: [] },
    }
  }
}

// Get service status
export async function GET() {
  try {
    // Sync processes with settings to ensure status is accurate
    await syncProcessesWithSettings()

    // Return the current status
    const status = loadStatus()
    return NextResponse.json({ success: true, status })
  } catch (error) {
    console.error("Failed to get service status:", error)
    return NextResponse.json({ success: false, error: "Failed to get service status" }, { status: 500 })
  }
}

// Start/stop services
export async function POST(request: Request) {
  try {
    const { action, service } = await request.json()

    if (!action || !service) {
      return NextResponse.json({ success: false, error: "Missing required parameters" }, { status: 400 })
    }

    let result = { success: false, error: "Invalid action or service" }

    // Handle different actions
    if (service === "live") {
      if (action === "start") {
        result = await startLiveTrading()
      } else if (action === "stop") {
        result = stopLiveTrading()
      }
    } else if (service === "simulation") {
      if (action === "start") {
        result = await startSimulation()
      } else if (action === "stop") {
        result = stopSimulation()
      }
    } else if (service === "all") {
      if (action === "sync") {
        result = await syncProcessesWithSettings()
      }
    }

    if (!result.success) {
      return NextResponse.json({ success: false, error: result.error || "Operation failed" }, { status: 500 })
    }

    // Return the updated status
    const status = loadStatus()
    return NextResponse.json({ success: true, status })
  } catch (error) {
    console.error("Service operation failed:", error)
    return NextResponse.json({ success: false, error: "Service operation failed" }, { status: 500 })
  }
}
