import { NextResponse } from "next/server"
import { BinanceExchange } from "@/lib/exchanges/binance"
import { BybitExchange } from "@/lib/exchanges/bybit"
import { OKXExchange } from "@/lib/exchanges/okx"
import type { PriceData } from "@/lib/types"

// Initialize exchanges on the server side
const binanceExchange = new BinanceExchange(process.env.BINANCE_API_KEY || "", process.env.BINANCE_API_SECRET || "")

const bybitExchange = new BybitExchange(process.env.BYBIT_API_KEY || "", process.env.BYBIT_API_SECRET || "")

const okxExchange = new OKXExchange(
  process.env.OKX_API_KEY || "",
  process.env.OKX_API_SECRET || "",
  process.env.OKX_PASSPHRASE || "",
)

// Map to store exchange instances
const exchanges = new Map()
exchanges.set("Binance", binanceExchange)
exchanges.set("Bybit", bybitExchange)
exchanges.set("OKX", okxExchange)

// Connect status for exchanges
let exchangesConnected = false

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const pair = searchParams.get("pair")

  if (!pair) {
    return NextResponse.json({ error: "Pair parameter is required" }, { status: 400 })
  }

  try {
    // Connect to exchanges if not already connected
    if (!exchangesConnected) {
      for (const [name, exchange] of exchanges.entries()) {
        await exchange.connect()
      }
      exchangesConnected = true
    }

    // Get prices from all exchanges
    const prices: PriceData[] = []
    for (const [name, exchange] of exchanges.entries()) {
      try {
        const price = await exchange.getPrice(pair)
        prices.push(price)
      } catch (error) {
        console.error(`Failed to get ${pair} price from ${name}:`, error)
      }
    }

    return NextResponse.json({ success: true, prices })
  } catch (error) {
    console.error("Error fetching market data:", error)
    return NextResponse.json({ success: false, error: "Failed to fetch market data" }, { status: 500 })
  }
}
