import { NextResponse } from "next/server"
import { generateVerificationCode } from "@/lib/email-service"

export async function POST(request: Request) {
  try {
    const { email } = await request.json()

    if (!email) {
      return NextResponse.json({ success: false, error: "Email is required" }, { status: 400 })
    }

    const { success, error } = await generateVerificationCode(email)

    if (!success) {
      return NextResponse.json(
        { success: false, error: error || "Failed to generate verification code" },
        { status: 500 },
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error resending verification code:", error)
    return NextResponse.json({ success: false, error: "An unexpected error occurred" }, { status: 500 })
  }
}
