import { NextResponse } from "next/server"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { generateVerificationCode } from "@/lib/email-service"

export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const username = formData.get("username") as string

    if (!email || !password || !username) {
      return NextResponse.json({ success: false, error: "Missing required fields" }, { status: 400 })
    }

    const supabase = createServerSupabaseClient()

    // Generate and send verification code
    const { success, error: codeError } = await generateVerificationCode(email)

    if (!success) {
      return NextResponse.json(
        { success: false, error: codeError || "Failed to generate verification code" },
        { status: 500 },
      )
    }

    // Create the user
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username,
        },
      },
    })

    if (error) {
      return NextResponse.json({ success: false, error: error.message }, { status: 400 })
    }

    return NextResponse.json({ success: true, email })
  } catch (error) {
    console.error("Sign up error:", error)
    return NextResponse.json({ success: false, error: "An unexpected error occurred" }, { status: 500 })
  }
}
