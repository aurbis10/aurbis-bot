export default function Head() {
  return (
    <>
      <title>Aurbis Arbitrage</title>
      <meta content="width=device-width, initial-scale=1" name="viewport" />
      <meta name="description" content="Crypto arbitrage trading platform" />
      <link rel="icon" href="/favicon.ico" />
    </>
  )
}
