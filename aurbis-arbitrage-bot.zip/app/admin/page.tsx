"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, AlertTriangle, Save, RefreshCw, RotateCcw } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"

export default function AdminPage() {
  const router = useRouter()
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [saveLoading, setSaveLoading] = useState(false)
  const [resetLoading, setResetLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("live")
  const [isUserSettings, setIsUserSettings] = useState(false)

  // Settings state
  const [settings, setSettings] = useState({
    live: {
      autoTrading: false,
      continuous: false,
      minSpread: 1.3,
      tradeSize: 100,
      checkInterval: 3,
    },
    simulation: {
      autoTrading: false,
      continuous: false,
      minSpread: 1.3,
      tradeSize: 50,
      checkInterval: 3,
    },
  })

  // Add a retry function for fetching settings
  const fetchSettingsWithRetry = async (retries = 3) => {
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        console.log(`Fetching settings, attempt ${attempt + 1}/${retries}`)
        const response = await fetch("/api/admin/settings")

        if (!response.ok) {
          throw new Error(`Server responded with status: ${response.status}`)
        }

        const data = await response.json()

        if (data.success) {
          console.log("Settings loaded successfully:", data.settings)
          setSettings(data.settings)
          setIsUserSettings(data.isUserSettings || false)
          if (data.warning) {
            console.warn("Settings warning:", data.warning)
          }
          return true
        } else {
          throw new Error(data.error || "Failed to load settings")
        }
      } catch (err) {
        console.error(`Error fetching settings (attempt ${attempt + 1}/${retries}):`, err)

        if (attempt === retries - 1) {
          setError("Failed to load settings. Please try again.")
          return false
        }

        // Wait before retrying (exponential backoff)
        await new Promise((resolve) => setTimeout(resolve, 1000 * Math.pow(2, attempt)))
      }
    }
    return false
  }

  // Add a refresh function
  const refreshSettings = async () => {
    setLoading(true)
    setError(null)
    await fetchSettingsWithRetry()
    setLoading(false)
  }

  // Reset user settings to global defaults
  const resetToDefaults = async () => {
    if (!user) {
      setError("You must be logged in to reset settings")
      return
    }

    setResetLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/admin/settings/reset", {
        method: "POST",
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Server responded with status: ${response.status}. ${errorText}`)
      }

      const data = await response.json()
      if (data.success) {
        setSettings(data.settings)
        setSuccess("Settings reset to global defaults")
      } else {
        throw new Error(data.error || "Failed to reset settings")
      }
    } catch (error) {
      console.error("Failed to reset settings:", error)
      setError(`Failed to reset settings: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setResetLoading(false)
    }
  }

  // Update the useEffect to use the retry function
  useEffect(() => {
    async function loadSettings() {
      setLoading(true)
      setError(null)
      await fetchSettingsWithRetry()
      setLoading(false)
    }

    loadSettings()
  }, [])

  // Save settings - fixed to ensure it works properly
  const saveSettings = async () => {
    console.log("Save settings button clicked")
    setSaveLoading(true)
    setError(null)
    setSuccess(null)

    try {
      // Validate settings before sending
      const validatedSettings = {
        live: {
          autoTrading: Boolean(settings.live.autoTrading),
          continuous: Boolean(settings.live.continuous),
          minSpread: Number(settings.live.minSpread),
          tradeSize: Number(settings.live.tradeSize),
          checkInterval: Number(settings.live.checkInterval),
        },
        simulation: {
          autoTrading: Boolean(settings.simulation.autoTrading),
          continuous: Boolean(settings.simulation.continuous),
          minSpread: Number(settings.simulation.minSpread),
          tradeSize: Number(settings.simulation.tradeSize),
          checkInterval: Number(settings.simulation.checkInterval),
        },
      }

      console.log("Saving settings:", validatedSettings)
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ settings: validatedSettings }),
      })

      console.log("Save settings response status:", response.status)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("Error response text:", errorText)
        throw new Error(`Server responded with status: ${response.status}. ${errorText}`)
      }

      const data = await response.json()
      console.log("Save settings response data:", data)

      if (data.success) {
        setSuccess("Settings saved successfully")
        // Update local settings with the ones returned from the server
        if (data.settings) {
          setSettings(data.settings)
        }
        setIsUserSettings(data.isUserSettings || false)
      } else {
        setError(data.error || "Failed to save settings")
      }
    } catch (err) {
      console.error("Error saving settings:", err)
      setError(`Failed to save settings: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setSaveLoading(false)
    }
  }

  // Save settings for the current tab only
  const saveCurrentTabSettings = async () => {
    console.log(`Saving ${activeTab} settings`)
    setSaveLoading(true)
    setError(null)
    setSuccess(null)

    try {
      // Validate settings before sending
      let tabSettings: any = {}

      if (activeTab === "live") {
        tabSettings = {
          live: {
            autoTrading: Boolean(settings.live.autoTrading),
            continuous: Boolean(settings.live.continuous),
            minSpread: Number(settings.live.minSpread),
            tradeSize: Number(settings.live.tradeSize),
            checkInterval: Number(settings.live.checkInterval),
          },
        }
      } else {
        tabSettings = {
          simulation: {
            autoTrading: Boolean(settings.simulation.autoTrading),
            continuous: Boolean(settings.simulation.continuous),
            minSpread: Number(settings.simulation.minSpread),
            tradeSize: Number(settings.simulation.tradeSize),
            checkInterval: Number(settings.simulation.checkInterval),
          },
        }
      }

      console.log("Saving tab settings:", tabSettings)

      const response = await fetch(`/api/admin/settings/${activeTab}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ settings: tabSettings }),
      })

      console.log("Save tab settings response status:", response.status)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("Error response text:", errorText)
        throw new Error(`Server responded with status: ${response.status}. ${errorText}`)
      }

      const data = await response.json()
      console.log("Save tab settings response data:", data)

      if (data.success) {
        setSuccess(`${activeTab === "live" ? "Live" : "Simulation"} settings saved successfully`)
        // Update local settings with the ones returned from the server
        if (data.settings) {
          setSettings(data.settings)
        }
        setIsUserSettings(data.isUserSettings || false)
      } else {
        setError(data.error || `Failed to save ${activeTab} settings`)
      }
    } catch (err) {
      console.error(`Error saving ${activeTab} settings:`, err)
      setError(`Failed to save ${activeTab} settings: ${err instanceof Error ? err.message : "Unknown error"}`)
    } finally {
      setSaveLoading(false)
    }
  }

  // Toggle auto-trading for live mode
  const toggleLiveAutoTrading = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      live: {
        ...prev.live,
        autoTrading: value,
      },
    }))
  }

  // Toggle continuous operation for live mode
  const toggleLiveContinuous = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      live: {
        ...prev.live,
        continuous: value,
      },
    }))
  }

  // Toggle auto-trading for simulation mode
  const toggleSimulationAutoTrading = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      simulation: {
        ...prev.simulation,
        autoTrading: value,
      },
    }))
  }

  // Toggle continuous operation for simulation mode
  const toggleSimulationContinuous = async (value: boolean) => {
    setSettings((prev) => ({
      ...prev,
      simulation: {
        ...prev.simulation,
        continuous: value,
      },
    }))
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
      </div>
    )
  }

  return (
    <main className="container mx-auto p-4 space-y-6">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          {isUserSettings && user && (
            <Badge variant="outline" className="bg-blue-50">
              Personal Settings
            </Badge>
          )}
          {!isUserSettings && (
            <Badge variant="outline" className="bg-gray-50">
              Global Settings
            </Badge>
          )}
        </div>
        <div className="space-x-2">
          {user && isUserSettings && (
            <Button variant="outline" onClick={resetToDefaults} disabled={resetLoading}>
              {resetLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RotateCcw className="mr-2 h-4 w-4" />
              )}
              Reset to Defaults
            </Button>
          )}
          <Button variant="outline" onClick={refreshSettings} disabled={loading}>
            {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            Refresh
          </Button>
          <Link href="/">
            <Button variant="outline">Back to Dashboard</Button>
          </Link>
        </div>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="bg-green-50 border-green-200 text-green-800">
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      {!user && (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Not Logged In</AlertTitle>
          <AlertDescription>
            You are viewing global settings. Log in to create and save your personal settings.
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="live" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="live">Live Trading</TabsTrigger>
          <TabsTrigger value="simulation">Simulation</TabsTrigger>
        </TabsList>

        <TabsContent value="live">
          <Card>
            <CardHeader>
              <CardTitle>Live Trading Settings</CardTitle>
              <CardDescription>Configure how the arbitrage bot will operate in live trading mode</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="live-autoTrading" className="text-base">
                      Auto Trading
                    </Label>
                    <p className="text-sm text-gray-500">
                      Automatically execute trades when opportunities are detected
                    </p>
                  </div>
                  <Switch
                    id="live-autoTrading"
                    checked={settings.live.autoTrading}
                    onCheckedChange={toggleLiveAutoTrading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="live-continuous" className="text-base">
                      24/7 Operation
                    </Label>
                    <p className="text-sm text-gray-500">Run continuously looking for arbitrage opportunities</p>
                  </div>
                  <Switch
                    id="live-continuous"
                    checked={settings.live.continuous}
                    onCheckedChange={toggleLiveContinuous}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="live-minSpread">Minimum Spread (%)</Label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      id="live-minSpread"
                      min="0.5"
                      max="5.0"
                      step="0.1"
                      value={settings.live.minSpread}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          live: {
                            ...settings.live,
                            minSpread: Number.parseFloat(e.target.value),
                          },
                        })
                      }
                      className="w-full"
                    />
                    <span className="ml-2 min-w-[40px] text-right">{settings.live.minSpread}%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="live-tradeSize">Trade Size (USDT)</Label>
                  <input
                    type="number"
                    id="live-tradeSize"
                    value={settings.live.tradeSize}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        live: {
                          ...settings.live,
                          tradeSize: Number.parseInt(e.target.value) || 0,
                        },
                      })
                    }
                    className="w-full p-2 border rounded-md"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="live-checkInterval">Check Interval (seconds)</Label>
                  <input
                    type="number"
                    id="live-checkInterval"
                    value={settings.live.checkInterval}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        live: {
                          ...settings.live,
                          checkInterval: Number.parseInt(e.target.value) || 3,
                        },
                      })
                    }
                    min="1"
                    max="60"
                    className="w-full p-2 border rounded-md"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveSettings} disabled={saveLoading} className="ml-auto">
                {saveLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                Save Live Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="simulation">
          <Card>
            <CardHeader>
              <CardTitle>Simulation Settings</CardTitle>
              <CardDescription>Configure how the simulation mode will operate</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sim-autoTrading" className="text-base">
                      Auto Trading
                    </Label>
                    <p className="text-sm text-gray-500">
                      Automatically execute simulated trades when opportunities are detected
                    </p>
                  </div>
                  <Switch
                    id="sim-autoTrading"
                    checked={settings.simulation.autoTrading}
                    onCheckedChange={toggleSimulationAutoTrading}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="sim-continuous" className="text-base">
                      24/7 Operation
                    </Label>
                    <p className="text-sm text-gray-500">Run simulation continuously</p>
                  </div>
                  <Switch
                    id="sim-continuous"
                    checked={settings.simulation.continuous}
                    onCheckedChange={toggleSimulationContinuous}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sim-minSpread">Minimum Spread (%)</Label>
                  <div className="flex items-center">
                    <input
                      type="range"
                      id="sim-minSpread"
                      min="0.5"
                      max="5.0"
                      step="0.1"
                      value={settings.simulation.minSpread}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          simulation: {
                            ...settings.simulation,
                            minSpread: Number.parseFloat(e.target.value),
                          },
                        })
                      }
                      className="w-full"
                    />
                    <span className="ml-2 min-w-[40px] text-right">{settings.simulation.minSpread}%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sim-tradeSize">Trade Size (USDT)</Label>
                  <input
                    type="number"
                    id="sim-tradeSize"
                    value={settings.simulation.tradeSize}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        simulation: {
                          ...settings.simulation,
                          tradeSize: Number.parseInt(e.target.value) || 0,
                        },
                      })
                    }
                    className="w-full p-2 border rounded-md"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sim-checkInterval">Check Interval (seconds)</Label>
                  <input
                    type="number"
                    id="sim-checkInterval"
                    value={settings.simulation.checkInterval}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        simulation: {
                          ...settings.simulation,
                          checkInterval: Number.parseInt(e.target.value) || 3,
                        },
                      })
                    }
                    min="1"
                    max="60"
                    className="w-full p-2 border rounded-md"
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveSettings} disabled={saveLoading} className="ml-auto">
                {saveLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                Save Simulation Settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>System Status</CardTitle>
          <CardDescription>Current status of the arbitrage system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2 border p-4 rounded-lg">
              <h3 className="font-medium">Live System</h3>
              <div className="flex items-center justify-between">
                <span>Status:</span>
                <span className={`font-medium ${settings.live.continuous ? "text-green-500" : "text-gray-500"}`}>
                  {settings.live.continuous ? "Running" : "Stopped"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Auto-Trading:</span>
                <span className={`font-medium ${settings.live.autoTrading ? "text-green-500" : "text-yellow-500"}`}>
                  {settings.live.autoTrading ? "Enabled" : "Disabled"}
                </span>
              </div>
            </div>

            <div className="space-y-2 border p-4 rounded-lg">
              <h3 className="font-medium">Simulation</h3>
              <div className="flex items-center justify-between">
                <span>Status:</span>
                <span className={`font-medium ${settings.simulation.continuous ? "text-green-500" : "text-gray-500"}`}>
                  {settings.simulation.continuous ? "Running" : "Stopped"}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Auto-Trading:</span>
                <span
                  className={`font-medium ${settings.simulation.autoTrading ? "text-green-500" : "text-yellow-500"}`}
                >
                  {settings.simulation.autoTrading ? "Enabled" : "Disabled"}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </main>
  )
}
