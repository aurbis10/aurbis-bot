"use client"

import { Button } from "@/components/ui/button"
import Link from "next/link"

export function UserProfile() {
  // Simplified version without authentication
  return (
    <Link href="/">
      <Button variant="ghost" size="sm">
        Aurbis Arbitrage
      </Button>
    </Link>
  )
}
