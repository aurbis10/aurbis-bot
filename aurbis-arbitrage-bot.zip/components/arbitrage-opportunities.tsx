"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUpDown } from "lucide-react"
import { useState, useEffect } from "react"

type ArbitrageOpportunity = {
  id: string
  pair: string
  buyExchange: string
  sellExchange: string
  spread: number
  buyPrice: number
  sellPrice: number
  timestamp: Date
}

export function ArbitrageOpportunities() {
  const [opportunities, setOpportunities] = useState<ArbitrageOpportunity[]>([])

  // Simulate new opportunities
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        const newOpportunity: ArbitrageOpportunity = {
          id: Math.random().toString(36).substring(2, 9),
          pair: ["BTC/USDT", "ETH/USDT", "SOL/USDT"][Math.floor(Math.random() * 3)],
          buyExchange: ["Binance", "Bybit", "OKX"][Math.floor(Math.random() * 3)],
          sellExchange: ["Binance", "Bybit", "OKX"][Math.floor(Math.random() * 3)],
          spread: Number.parseFloat((Math.random() * 2 + 0.8).toFixed(2)),
          buyPrice: Number.parseFloat((Math.random() * 1000 + 20000).toFixed(2)),
          sellPrice: Number.parseFloat((Math.random() * 1000 + 20000).toFixed(2)),
          timestamp: new Date(),
        }

        // Ensure buy and sell exchanges are different
        if (newOpportunity.buyExchange !== newOpportunity.sellExchange) {
          setOpportunities((prev) => [newOpportunity, ...prev].slice(0, 5))
        }
      }
    }, 8000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Arbitrage Opportunities</CardTitle>
        <CardDescription>Recent price differences across exchanges</CardDescription>
      </CardHeader>
      <CardContent>
        {opportunities.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No arbitrage opportunities detected yet.
            <p className="text-sm mt-2">Waiting for favorable market conditions...</p>
          </div>
        ) : (
          <div className="space-y-4">
            {opportunities.map((opportunity) => (
              <div key={opportunity.id} className="border rounded-lg p-3 hover:bg-muted/50 transition-colors">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold">{opportunity.pair}</span>
                  <span
                    className={`font-medium ${
                      opportunity.spread >= 1.5
                        ? "text-green-500"
                        : opportunity.spread >= 1.0
                          ? "text-amber-500"
                          : "text-gray-500"
                    }`}
                  >
                    {opportunity.spread}% Spread
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div>
                    <p className="text-gray-500">Buy at {opportunity.buyExchange}</p>
                    <p className="font-medium">${opportunity.buyPrice.toLocaleString()}</p>
                  </div>
                  <ArrowUpDown className="h-4 w-4 mx-2 text-gray-400" />
                  <div className="text-right">
                    <p className="text-gray-500">Sell at {opportunity.sellExchange}</p>
                    <p className="font-medium">${opportunity.sellPrice.toLocaleString()}</p>
                  </div>
                </div>
                <div className="text-xs text-gray-400 mt-2 text-right">
                  {opportunity.timestamp.toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
