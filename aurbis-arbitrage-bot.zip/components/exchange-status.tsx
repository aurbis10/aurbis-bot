"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useState, useEffect } from "react"

type ExchangeStatusType = {
  name: string
  status: "connected" | "disconnected" | "error"
  latency: number
}

export function ExchangeStatus() {
  const [exchanges, setExchanges] = useState<ExchangeStatusType[]>([
    { name: "Binance", status: "connected", latency: 45 },
    { name: "Bybit", status: "connected", latency: 78 },
    { name: "OKX", status: "connected", latency: 62 },
  ])

  // Simulate random latency changes
  useEffect(() => {
    const interval = setInterval(() => {
      setExchanges((prev) =>
        prev.map((exchange) => ({
          ...exchange,
          latency: Math.floor(Math.random() * 100) + 20,
          status: Math.random() > 0.9 ? "error" : "connected",
        })),
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Exchange Status</CardTitle>
        <CardDescription>Connection to trading platforms</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {exchanges.map((exchange) => (
            <div key={exchange.name} className="flex justify-between items-center p-2 bg-muted/50 rounded-md">
              <div className="flex items-center">
                <div
                  className={`w-2 h-2 rounded-full mr-2 ${
                    exchange.status === "connected"
                      ? "bg-green-500"
                      : exchange.status === "error"
                        ? "bg-red-500"
                        : "bg-gray-500"
                  }`}
                ></div>
                <span className="font-medium">{exchange.name}</span>
              </div>
              <div className="flex items-center">
                <Badge
                  variant={exchange.latency < 50 ? "default" : exchange.latency < 100 ? "secondary" : "destructive"}
                >
                  {exchange.latency}ms
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
