"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Pause, RefreshCw } from "lucide-react"
import { useState } from "react"

export function BotStatus() {
  const [isRunning, setIsRunning] = useState(false)
  const [lastScan, setLastScan] = useState<string | null>("Never")

  const toggleBot = () => {
    setIsRunning(!isRunning)
    if (!isRunning) {
      setLastScan(new Date().toLocaleTimeString())
    }
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Bot Status</CardTitle>
        <CardDescription>Current operational status</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center justify-center w-24 h-24 rounded-full border-4 border-gray-200">
            <div
              className={`w-16 h-16 rounded-full flex items-center justify-center ${
                isRunning ? "bg-green-500 animate-pulse" : "bg-gray-300"
              }`}
            >
              {isRunning ? (
                <RefreshCw className="h-8 w-8 text-white animate-spin" />
              ) : (
                <Pause className="h-8 w-8 text-gray-500" />
              )}
            </div>
          </div>
          <div className="text-center">
            <p className="text-lg font-medium">{isRunning ? "Running" : "Stopped"}</p>
            <p className="text-sm text-gray-500">Last scan: {lastScan}</p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button onClick={toggleBot} variant={isRunning ? "destructive" : "default"} className="w-full">
          {isRunning ? (
            <>
              <Pause className="mr-2 h-4 w-4" /> Stop Bot
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" /> Start Bot
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
