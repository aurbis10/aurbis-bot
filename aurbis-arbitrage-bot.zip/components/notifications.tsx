"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Bell, X } from "lucide-react"
import { notificationService } from "@/lib/notification"

interface Notification {
  type: "info" | "success" | "warning" | "error"
  message: string
  timestamp: Date
}

export function Notifications() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [unreadCount, setUnreadCount] = useState(0)

  useEffect(() => {
    // Get initial notifications
    setNotifications(notificationService.getNotifications())

    // Subscribe to new notifications
    const unsubscribe = notificationService.subscribe((notification) => {
      setNotifications((prev) => [notification, ...prev])
      setUnreadCount((prev) => prev + 1)
    })

    // Cleanup subscription
    return () => unsubscribe()
  }, [])

  const toggleOpen = () => {
    setIsOpen(!isOpen)
    if (!isOpen) {
      setUnreadCount(0)
    }
  }

  return (
    <div className="relative">
      <button onClick={toggleOpen} className="relative p-2 rounded-full hover:bg-gray-100 transition-colors">
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute top-0 right-0 inline-flex items-center justify-center w-4 h-4 text-xs font-bold text-white bg-red-500 rounded-full">
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <Card className="absolute right-0 mt-2 w-80 z-50 shadow-lg">
          <CardHeader className="pb-2 flex flex-row justify-between items-center">
            <CardTitle className="text-sm">Notifications</CardTitle>
            <button onClick={() => setIsOpen(false)} className="text-gray-500 hover:text-gray-700">
              <X className="h-4 w-4" />
            </button>
          </CardHeader>
          <CardContent className="max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <p className="text-center text-gray-500 py-4">No notifications</p>
            ) : (
              <div className="space-y-2">
                {notifications.map((notification, index) => (
                  <div key={index} className="p-2 border-b last:border-0">
                    <div className="flex justify-between items-start">
                      <Badge
                        variant={
                          notification.type === "error"
                            ? "destructive"
                            : notification.type === "warning"
                              ? "warning"
                              : notification.type === "success"
                                ? "success"
                                : "secondary"
                        }
                        className="mb-1"
                      >
                        {notification.type}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        {new Date(notification.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm">{notification.message}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
