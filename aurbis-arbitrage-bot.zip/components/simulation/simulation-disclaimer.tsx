"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle, Clock, DollarSign, BarChart2, Zap } from "lucide-react"

export function SimulationDisclaimer() {
  return (
    <Card className="border-amber-200 bg-amber-50">
      <CardHeader className="pb-2">
        <CardTitle className="text-amber-800 flex items-center">
          <AlertTriangle className="h-5 w-5 mr-2" />
          Simulation vs. Real-World Trading
        </CardTitle>
      </CardHeader>
      <CardContent className="text-amber-800">
        <p className="text-sm mb-4">
          This simulation includes real-world factors that affect trading performance, but actual results may differ:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-start">
            <Clock className="h-5 w-5 mr-2 mt-0.5 text-amber-700 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-medium">Latency</h4>
              <p className="text-xs text-amber-700">
                Network delays and API response times are simulated but may be different in production.
              </p>
            </div>
          </div>

          <div className="flex items-start">
            <DollarSign className="h-5 w-5 mr-2 mt-0.5 text-amber-700 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-medium">Fees & Slippage</h4>
              <p className="text-xs text-amber-700">
                Exchange fees and price slippage are modeled but can vary based on market conditions.
              </p>
            </div>
          </div>

          <div className="flex items-start">
            <BarChart2 className="h-5 w-5 mr-2 mt-0.5 text-amber-700 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-medium">Liquidity</h4>
              <p className="text-xs text-amber-700">
                Limited market depth can prevent orders from filling at expected prices.
              </p>
            </div>
          </div>

          <div className="flex items-start">
            <Zap className="h-5 w-5 mr-2 mt-0.5 text-amber-700 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-medium">Volatility</h4>
              <p className="text-xs text-amber-700">
                Sudden price movements can dramatically affect execution quality and profitability.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
