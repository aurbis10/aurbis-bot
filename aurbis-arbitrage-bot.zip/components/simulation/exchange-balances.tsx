"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { simulationEngine, type SimulatedAccount } from "@/lib/simulation/simulation-engine"

export function ExchangeBalances() {
  const [accounts, setAccounts] = useState<SimulatedAccount[]>([])

  useEffect(() => {
    // Get initial accounts
    setAccounts(simulationEngine.getAllAccounts())

    // Subscribe to stats updates which will trigger when trades happen
    const unsubscribe = simulationEngine.subscribe(() => {
      setAccounts(simulationEngine.getAllAccounts())
    })

    return () => {
      unsubscribe()
    }
  }, [])

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Exchange Balances</CardTitle>
        <CardDescription>Simulated account balances</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {accounts.map((account) => (
            <div key={account.exchange} className="border rounded-lg p-3">
              <div className="flex justify-between items-center mb-2">
                <span className="font-bold">{account.exchange}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(account.balances).map(([currency, balance]) => (
                  <div key={`${account.exchange}-${currency}`} className="bg-gray-50 p-2 rounded">
                    <p className="text-xs text-gray-500">{currency}</p>
                    <p className="font-medium">{balance.toFixed(currency === "USDT" ? 2 : 6)}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
