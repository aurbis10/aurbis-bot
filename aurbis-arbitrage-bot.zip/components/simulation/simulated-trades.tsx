"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { simulationEngine, type ArbitrageTrade } from "@/lib/simulation/simulation-engine"
import { Clock, Zap, BarChart } from "lucide-react"

export function SimulatedTrades() {
  const [trades, setTrades] = useState<ArbitrageTrade[]>([])

  useEffect(() => {
    // Get initial trades
    setTrades(simulationEngine.getLatestArbitrageTrades(10))

    // Subscribe to stats updates which will trigger when trades happen
    const unsubscribe = simulationEngine.subscribe(() => {
      setTrades(simulationEngine.getLatestArbitrageTrades(10))
    })

    return () => {
      unsubscribe()
    }
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Simulated Trades</CardTitle>
        <CardDescription>Recent arbitrage trades executed by the bot</CardDescription>
      </CardHeader>
      <CardContent>
        {trades.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No trades executed yet.
            <p className="text-sm mt-2">Start the simulation to see trades appear here.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {trades.map((trade) => (
              <div key={trade.id} className="border rounded-lg p-3 hover:bg-muted/50 transition-colors">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold">{trade.pair}</span>
                  <Badge
                    variant={trade.status === "completed" ? (trade.profit > 0 ? "success" : "warning") : "destructive"}
                  >
                    {trade.status === "completed" ? (trade.profit > 0 ? "Profit" : "Loss") : "Failed"}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-gray-500">Buy</p>
                    <p className="font-medium">
                      {trade.buyExchange} @ ${trade.buyPrice.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Sell</p>
                    <p className="font-medium">
                      {trade.sellExchange} @ ${trade.sellPrice.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Amount</p>
                    <p className="font-medium">
                      {trade.amount.toFixed(6)} {trade.pair.split("/")[0]}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Spread</p>
                    <p className="font-medium">{trade.spread.toFixed(2)}%</p>
                  </div>
                </div>

                {/* Execution metrics */}
                {trade.status === "completed" && (
                  <div className="mt-2 grid grid-cols-3 gap-2 text-xs border-t pt-2">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1 text-gray-400" />
                      <span className="text-gray-500">Latency:</span>
                      <span className="ml-1 font-medium">{trade.totalLatency || 0}ms</span>
                    </div>
                    <div className="flex items-center">
                      <Zap className="h-3 w-3 mr-1 text-gray-400" />
                      <span className="text-gray-500">Slippage:</span>
                      <span className="ml-1 font-medium">
                        {((trade.buyTrade.slippage || 0) + (trade.sellTrade.slippage || 0)).toFixed(2)}%
                      </span>
                    </div>
                    <div className="flex items-center">
                      <BarChart className="h-3 w-3 mr-1 text-gray-400" />
                      <span className="text-gray-500">Quality:</span>
                      <span
                        className={`ml-1 font-medium ${
                          (trade.executionQuality || 0) > 70
                            ? "text-green-600"
                            : (trade.executionQuality || 0) > 40
                              ? "text-amber-600"
                              : "text-red-600"
                        }`}
                      >
                        {trade.executionQuality || 0}/100
                      </span>
                    </div>
                  </div>
                )}

                <div className="mt-2 pt-2 border-t flex justify-between items-center">
                  <div className="text-xs text-gray-400">{trade.timestamp.toLocaleString()}</div>
                  <div className={`font-medium ${trade.profit > 0 ? "text-green-500" : "text-red-500"}`}>
                    {trade.profit > 0 ? "+" : ""}${trade.profit.toFixed(2)} ({trade.profitPercentage.toFixed(2)}%)
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
