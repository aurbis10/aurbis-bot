"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { ArrowUp, ArrowDown, BarChart2, Clock, AlertTriangle, Zap } from "lucide-react"
import { simulationEngine, type SimulationStats } from "@/lib/simulation/simulation-engine"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function SimulationStatistics() {
  const [stats, setStats] = useState<SimulationStats | null>(null)

  useEffect(() => {
    // Get initial stats
    setStats(simulationEngine.getStats())

    // Subscribe to stats updates
    const unsubscribe = simulationEngine.subscribe((newStats) => {
      setStats(newStats)
    })

    return () => {
      unsubscribe()
    }
  }, [])

  if (!stats) {
    return null
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Simulation Statistics</CardTitle>
        <CardDescription>Performance metrics for simulated trades</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="performance">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="execution">Execution</TabsTrigger>
            <TabsTrigger value="risk">Risk Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="performance" className="space-y-6">
            <div>
              <div className="flex justify-between mb-2">
                <h3 className="text-sm font-medium">Win Rate</h3>
                <span className="text-sm font-medium text-green-600">{stats.winRate.toFixed(1)}%</span>
              </div>
              <Progress value={stats.winRate} className="h-2" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Total Trades</h3>
                <div className="flex items-center">
                  <BarChart2 className="h-4 w-4 mr-2 text-gray-500" />
                  <span className="text-2xl font-bold">{stats.totalTrades}</span>
                </div>
                <div className="text-xs text-gray-500">
                  <span className="text-green-500">{stats.successfulTrades} successful</span> •
                  <span className="text-red-500 ml-1">{stats.failedTrades} failed</span>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Total Profit</h3>
                <div className="flex items-center">
                  {stats.totalProfit >= 0 ? (
                    <ArrowUp className="h-4 w-4 mr-2 text-green-500" />
                  ) : (
                    <ArrowDown className="h-4 w-4 mr-2 text-red-500" />
                  )}
                  <span className={`text-2xl font-bold ${stats.totalProfit >= 0 ? "text-green-600" : "text-red-600"}`}>
                    ${Math.abs(stats.totalProfit).toFixed(2)}
                  </span>
                </div>
                <div className="text-xs text-gray-500">
                  ROI:{" "}
                  <span className={stats.roi >= 0 ? "text-green-500" : "text-red-500"}>{stats.roi.toFixed(2)}%</span>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Largest Profit</h3>
                <div className="flex items-center">
                  <ArrowUp className="h-4 w-4 mr-2 text-green-500" />
                  <span className="text-xl font-bold text-green-600">${stats.largestProfit.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Largest Loss</h3>
                <div className="flex items-center">
                  <ArrowDown className="h-4 w-4 mr-2 text-red-500" />
                  <span className="text-xl font-bold text-red-600">${Math.abs(stats.largestLoss).toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t">
              <div className="flex justify-between mb-2">
                <h3 className="text-sm font-medium">Initial Balance</h3>
                <span className="text-sm">${stats.initialBalance.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <h3 className="text-sm font-medium">Current Balance</h3>
                <span
                  className={`text-sm font-medium ${stats.currentBalance >= stats.initialBalance ? "text-green-600" : "text-red-600"}`}
                >
                  ${stats.currentBalance.toFixed(2)}
                </span>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="execution" className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Average Latency</h3>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  <span className="text-xl font-bold">{stats.averageLatency.toFixed(0)} ms</span>
                </div>
                <div className="text-xs text-gray-500">Network and execution delay</div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Average Slippage</h3>
                <div className="flex items-center">
                  <Zap className="h-4 w-4 mr-2 text-amber-500" />
                  <span className="text-xl font-bold">{stats.averageSlippage.toFixed(2)}%</span>
                </div>
                <div className="text-xs text-gray-500">Price movement during execution</div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Total Fees</h3>
                <div className="flex items-center">
                  <span className="text-xl font-bold text-red-600">${stats.totalFees.toFixed(2)}</span>
                </div>
                <div className="text-xs text-gray-500">Exchange fees for all trades</div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Net Profit After Fees</h3>
                <div className="flex items-center">
                  <span
                    className={`text-xl font-bold ${stats.netProfitAfterFees >= 0 ? "text-green-600" : "text-red-600"}`}
                  >
                    ${stats.netProfitAfterFees.toFixed(2)}
                  </span>
                </div>
                <div className="text-xs text-gray-500">Profit after all fees and costs</div>
              </div>
            </div>

            <div className="pt-2 border-t">
              <div className="flex justify-between mb-2">
                <h3 className="text-sm font-medium">Volatility Impact</h3>
                <span
                  className={`text-sm font-medium ${
                    stats.volatilityImpact < 30
                      ? "text-green-600"
                      : stats.volatilityImpact < 60
                        ? "text-amber-600"
                        : "text-red-600"
                  }`}
                >
                  {stats.volatilityImpact.toFixed(0)}/100
                </span>
              </div>
              <Progress
                value={stats.volatilityImpact}
                className={`h-2 ${
                  stats.volatilityImpact < 30
                    ? "bg-green-600"
                    : stats.volatilityImpact < 60
                      ? "bg-amber-600"
                      : "bg-red-600"
                }`}
              />
              <p className="text-xs text-gray-500 mt-1">How market volatility affects performance</p>
            </div>
          </TabsContent>

          <TabsContent value="risk" className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Profit Factor</h3>
                <div className="flex items-center">
                  <span
                    className={`text-xl font-bold ${
                      stats.profitFactor > 2
                        ? "text-green-600"
                        : stats.profitFactor > 1
                          ? "text-amber-600"
                          : "text-red-600"
                    }`}
                  >
                    {stats.profitFactor.toFixed(2)}
                  </span>
                </div>
                <div className="text-xs text-gray-500">Ratio of gross profits to gross losses</div>
              </div>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Win/Loss Ratio</h3>
                <div className="flex items-center">
                  <span className="text-xl font-bold">
                    {stats.failedTrades > 0
                      ? (stats.successfulTrades / stats.failedTrades).toFixed(2)
                      : stats.successfulTrades > 0
                        ? "∞"
                        : "0.00"}
                  </span>
                </div>
                <div className="text-xs text-gray-500">Ratio of winning to losing trades</div>
              </div>

              <div className="space-y-2 col-span-2">
                <h3 className="text-sm font-medium">Risk Assessment</h3>
                <div className="bg-gray-100 p-3 rounded-md">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 mr-2 text-amber-500 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Performance Warning</p>
                      <p className="text-xs text-gray-600 mt-1">
                        {stats.roi > 100
                          ? "The current ROI is unusually high and may not be sustainable in real trading conditions."
                          : stats.averageSlippage > 0.5
                            ? "High slippage detected. Real-world execution may be significantly worse."
                            : stats.volatilityImpact > 50
                              ? "High market volatility impact detected. Strategy may be sensitive to market conditions."
                              : "Current performance metrics are within reasonable expectations for simulation."}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t">
              <h3 className="text-sm font-medium mb-2">Simulation vs. Real-World Factors</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-xs">Latency Simulation</span>
                  <span className="text-xs font-medium">Enabled</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs">Slippage Modeling</span>
                  <span className="text-xs font-medium">Enabled</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs">Liquidity Constraints</span>
                  <span className="text-xs font-medium">Enabled</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-xs">Market Volatility</span>
                  <span className="text-xs font-medium">Simulated</span>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
