"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { marketDataService } from "@/lib/market-data-service"
import type { PriceData } from "@/lib/types"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle } from "lucide-react"

export function MarketPrices() {
  const [prices, setPrices] = useState<Map<string, PriceData[]>>(new Map())
  const [isLoading, setIsLoading] = useState(true)
  const [volatility, setVolatility] = useState<string>("low")

  useEffect(() => {
    // Subscribe to price updates
    const unsubscribe = marketDataService.subscribeToPrices((newPrices) => {
      setPrices(new Map(newPrices))
      setIsLoading(false)
      setVolatility(marketDataService.getCurrentVolatility())
    })

    return () => {
      unsubscribe()
    }
  }, [])

  // Convert the Map to an array for easier rendering
  const pairsData = Array.from(prices.entries()).map(([pair, priceData]) => ({
    pair,
    prices: priceData,
  }))

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Market Prices</CardTitle>
            <CardDescription>Real-time cryptocurrency prices</CardDescription>
          </div>
          {volatility !== "low" && (
            <Badge variant={volatility === "high" ? "destructive" : "warning"} className="flex items-center">
              <AlertTriangle className="h-3 w-3 mr-1" />
              {volatility === "high" ? "High Volatility" : "Medium Volatility"}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-gray-500">Loading market data...</p>
          </div>
        ) : (
          <div className="space-y-6">
            {pairsData.map(({ pair, prices }) => (
              <div key={pair} className="space-y-2">
                <h3 className="text-lg font-medium">{pair}</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                  {prices.map((price) => (
                    <div
                      key={`${pair}-${price.exchange}`}
                      className={`border rounded-md p-3 ${
                        price.volatility === "high"
                          ? "border-red-200 bg-red-50"
                          : price.volatility === "medium"
                            ? "border-amber-200 bg-amber-50"
                            : ""
                      }`}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{price.exchange}</span>
                        <span className="text-xs text-gray-500">{new Date(price.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>
                          <p className="text-gray-500">Price</p>
                          <p className="font-bold">${price.price.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Spread</p>
                          <p
                            className={`font-medium ${
                              (price.ask - price.bid) > price.price * 0.005 ? "text-red-600" : "text-gray-700"
                            }`}
                          >
                            ${(price.ask - price.bid).toFixed(2)}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-500">Bid</p>
                          <p className="font-medium">${price.bid.toFixed(2)}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Ask</p>
                          <p className="font-medium">${price.ask.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
