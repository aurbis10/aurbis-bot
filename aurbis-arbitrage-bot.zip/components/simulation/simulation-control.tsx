"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Pause, RefreshCw, BarChart3, Settings } from "lucide-react"
import { simulationEngine } from "@/lib/simulation/simulation-engine"
import { marketDataService } from "@/lib/market-data-service"
import type { SimulationStats } from "@/lib/simulation/simulation-engine"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Alert, AlertDescription } from "@/components/ui/alert"

export function SimulationControl() {
  const [isRunning, setIsRunning] = useState(false)
  const [stats, setStats] = useState<SimulationStats | null>(null)
  const [elapsedTime, setElapsedTime] = useState(0)
  const [compoundProfits, setCompoundProfits] = useState(true)
  const [initialInvestment, setInitialInvestment] = useState(100)
  const [tradeSize, setTradeSize] = useState(50)
  const [minSpread, setMinSpread] = useState(1.3)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [saveLoading, setSaveLoading] = useState(false)

  useEffect(() => {
    // Initialize with current state
    setIsRunning(simulationEngine.isSimulationRunning())
    setStats(simulationEngine.getStats())

    // Subscribe to stats updates
    const unsubscribe = simulationEngine.subscribe((newStats) => {
      setStats(newStats)
    })

    // Set up timer for elapsed time
    let timer: NodeJS.Timeout | null = null
    if (isRunning) {
      timer = setInterval(() => {
        setElapsedTime((prev) => prev + 1)
      }, 1000)
    }

    // Configure win rate without pre-populating trades
    simulationEngine.manipulateWinRate(96)

    // Set initial ROI calculation parameters
    simulationEngine.setCompoundProfits(compoundProfits)
    simulationEngine.setInitialInvestment(initialInvestment)
    simulationEngine.setTradeSize(tradeSize)
    simulationEngine.setMinSpread(minSpread)

    // Load settings from admin panel if available
    const loadAdminSettings = async () => {
      try {
        const response = await fetch("/api/simulation/settings")
        if (response.ok) {
          const data = await response.json()
          if (data.success && data.settings) {
            const simSettings = data.settings
            setTradeSize(simSettings.tradeSize || 50)
            setMinSpread(simSettings.minSpread || 1.3)

            // Apply these settings to the simulation engine
            simulationEngine.setTradeSize(simSettings.tradeSize || 50)
            simulationEngine.setMinSpread(simSettings.minSpread || 1.3)

            // Log whether we're using user-specific settings
            console.log(`Using ${data.isUserSettings ? "user-specific" : "global"} simulation settings`)
          }
        }
      } catch (error) {
        console.error("Failed to load simulation settings:", error)
      }
    }

    loadAdminSettings()

    return () => {
      unsubscribe()
      if (timer) clearInterval(timer)
    }
  }, [isRunning, compoundProfits, initialInvestment])

  const toggleSimulation = async () => {
    if (isRunning) {
      simulationEngine.stop()
      marketDataService.stop()
      setIsRunning(false)
      setElapsedTime(0)

      // Reset the simulation with the current settings
      simulationEngine.manipulateWinRate(96)
      simulationEngine.setCompoundProfits(compoundProfits)
      simulationEngine.setInitialInvestment(initialInvestment)
      simulationEngine.setTradeSize(tradeSize)
      simulationEngine.setMinSpread(minSpread)
    } else {
      // Apply current settings before starting
      simulationEngine.setTradeSize(tradeSize)
      simulationEngine.setMinSpread(minSpread)

      // Start market data service first
      const marketStarted = await marketDataService.start()
      if (marketStarted) {
        simulationEngine.start()
        setIsRunning(true)
      }
    }
  }

  const handleCompoundChange = (checked: boolean) => {
    setCompoundProfits(checked)
    simulationEngine.setCompoundProfits(checked)
  }

  const handleInvestmentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseInt(e.target.value)
    if (!isNaN(value) && value > 0) {
      setInitialInvestment(value)
      simulationEngine.setInitialInvestment(value)
    }
  }

  const handleTradeSizeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number.parseInt(e.target.value)
    if (!isNaN(value) && value >= 0) {
      setTradeSize(value)
      simulationEngine.setTradeSize(value)
    }
  }

  const handleMinSpreadChange = (values: number[]) => {
    if (values.length > 0) {
      const value = values[0]
      setMinSpread(value)
      simulationEngine.setMinSpread(value)
    }
  }

  const formatElapsedTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  // Save settings to admin panel
  const saveSettingsToAdmin = async () => {
    setError(null)
    setSuccess(null)
    setSaveLoading(true)

    try {
      // Directly save to simulation settings API
      const simSettings = {
        minSpread: Number(minSpread),
        tradeSize: Number(tradeSize),
      }

      const response = await fetch("/api/simulation/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ settings: simSettings }),
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`Server responded with status: ${response.status}. ${errorText}`)
      }

      const data = await response.json()
      if (data.success) {
        setSuccess("Settings saved successfully")
        console.log("Simulation settings saved successfully")
      } else {
        throw new Error(data.error || "Failed to save settings")
      }
    } catch (error) {
      console.error("Failed to save settings:", error)
      setError(`Failed to save settings: ${error instanceof Error ? error.message : "Unknown error"}`)
    } finally {
      setSaveLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-lg">Simulation Control</CardTitle>
            <CardDescription>Run simulated trades with real market data</CardDescription>
          </div>
          <Popover open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="icon">
                <Settings className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80">
              <div className="space-y-4">
                <h4 className="font-medium">Simulation Settings</h4>

                {error && (
                  <Alert variant="destructive" className="py-2">
                    <AlertDescription className="text-xs">{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert variant="default" className="bg-green-50 border-green-200 text-green-800 py-2">
                    <AlertDescription className="text-xs">{success}</AlertDescription>
                  </Alert>
                )}

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="compound">Compound Profits</Label>
                    <p className="text-xs text-muted-foreground">Reinvest profits in subsequent trades</p>
                  </div>
                  <Switch id="compound" checked={compoundProfits} onCheckedChange={handleCompoundChange} />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="investment">Initial Investment ($)</Label>
                  <Input
                    id="investment"
                    type="number"
                    value={initialInvestment}
                    onChange={handleInvestmentChange}
                    min="1"
                  />
                  <p className="text-xs text-muted-foreground">Base amount for ROI calculation</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tradeSize">Trade Size (USDT)</Label>
                  <Input id="tradeSize" type="number" value={tradeSize} onChange={handleTradeSizeChange} min="0" />
                  <p className="text-xs text-muted-foreground">Amount to use for each trade</p>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="minSpread">Minimum Spread (%)</Label>
                    <span className="text-sm font-medium">{minSpread.toFixed(1)}%</span>
                  </div>
                  <Slider
                    id="minSpread"
                    min={0.5}
                    max={5.0}
                    step={0.1}
                    value={[minSpread]}
                    onValueChange={handleMinSpreadChange}
                  />
                  <p className="text-xs text-muted-foreground">Minimum spread required for arbitrage</p>
                </div>

                <Button
                  onClick={() => {
                    saveSettingsToAdmin()
                  }}
                  className="w-full"
                  disabled={saveLoading}
                >
                  {saveLoading ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Saving...
                    </>
                  ) : (
                    "Save Settings"
                  )}
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center space-y-4">
          <div className="flex items-center justify-center w-24 h-24 rounded-full border-4 border-gray-200">
            <div
              className={`w-16 h-16 rounded-full flex items-center justify-center ${
                isRunning ? "bg-green-500 animate-pulse" : "bg-gray-300"
              }`}
            >
              {isRunning ? (
                <RefreshCw className="h-8 w-8 text-white animate-spin" />
              ) : (
                <BarChart3 className="h-8 w-8 text-gray-500" />
              )}
            </div>
          </div>
          <div className="text-center">
            <p className="text-lg font-medium">{isRunning ? "Simulation Running" : "Simulation Stopped"}</p>
            {isRunning && <p className="text-sm text-gray-500">Running time: {formatElapsedTime(elapsedTime)}</p>}
          </div>

          {stats && (
            <div className="w-full grid grid-cols-2 gap-2 mt-2">
              <div className="bg-gray-100 p-2 rounded">
                <p className="text-xs text-gray-500">Win Rate</p>
                <p className="text-lg font-semibold text-green-600">{stats.winRate.toFixed(1)}%</p>
              </div>
              <div className="bg-gray-100 p-2 rounded">
                <p className="text-xs text-gray-500">Total Profit</p>
                <p className="text-lg font-semibold">${stats.totalProfit.toFixed(2)}</p>
              </div>
              <div className="bg-gray-100 p-2 rounded">
                <p className="text-xs text-gray-500">Trades</p>
                <p className="text-lg font-semibold">{stats.totalTrades}</p>
              </div>
              <div className="bg-gray-100 p-2 rounded">
                <p className="text-xs text-gray-500">ROI</p>
                <p className="text-lg font-semibold">{stats.roi.toFixed(2)}%</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button onClick={toggleSimulation} variant={isRunning ? "destructive" : "default"} className="w-full">
          {isRunning ? (
            <>
              <Pause className="mr-2 h-4 w-4" /> Stop Simulation
            </>
          ) : (
            <>
              <Play className="mr-2 h-4 w-4" /> Start Simulation
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
