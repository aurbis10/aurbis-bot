"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { simulationEngine } from "@/lib/simulation/simulation-engine"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface DataPoint {
  time: string
  profit: number
  cumulativeProfit: number
}

export function ProfitChart() {
  const [chartData, setChartData] = useState<DataPoint[]>([])

  useEffect(() => {
    // Function to update chart data
    const updateChartData = () => {
      const trades = simulationEngine.getArbitrageTrades()

      // Only use completed trades
      const completedTrades = trades
        .filter((trade) => trade.status === "completed")
        .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime())

      if (completedTrades.length === 0) return

      // Create data points with cumulative profit
      let cumulativeProfit = 0
      const data: DataPoint[] = completedTrades.map((trade) => {
        cumulativeProfit += trade.profit
        return {
          time: trade.timestamp.toLocaleTimeString(),
          profit: trade.profit,
          cumulativeProfit: cumulativeProfit,
        }
      })

      // Limit to last 20 points to avoid overcrowding
      setChartData(data.slice(-20))
    }

    // Update initially
    updateChartData()

    // Subscribe to updates
    const unsubscribe = simulationEngine.subscribe(() => {
      updateChartData()
    })

    return () => {
      unsubscribe()
    }
  }, [])

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Profit Over Time</CardTitle>
          <CardDescription>Visualization of cumulative profit</CardDescription>
        </CardHeader>
        <CardContent className="h-[300px] flex items-center justify-center">
          <p className="text-gray-500">No trade data available yet. Start the simulation to see profit chart.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Profit Over Time</CardTitle>
        <CardDescription>Visualization of cumulative profit</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{
                top: 5,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis />
              <Tooltip
                formatter={(value: number) => [`$${value.toFixed(2)}`, "Profit"]}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <Line
                type="monotone"
                dataKey="cumulativeProfit"
                stroke="#10b981"
                activeDot={{ r: 8 }}
                name="Cumulative Profit"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
