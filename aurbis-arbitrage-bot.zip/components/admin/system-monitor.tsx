"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Play, Pause, RefreshCw, AlertTriangle, CheckCircle, Clock, BarChart2, Terminal } from "lucide-react"

interface SystemStatus {
  live: {
    running: boolean
    lastStart: string | null
    lastCheck: string | null
    errors: Array<{ timestamp: string; message: string }>
  }
  simulation: {
    running: boolean
    lastStart: string | null
    lastCheck: string | null
    errors: Array<{ timestamp: string; message: string }>
  }
}

export function SystemMonitor() {
  const [status, setStatus] = useState<SystemStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [refreshInterval, setRefreshInterval] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)

  // Fetch status
  const fetchStatus = async () => {
    try {
      const response = await fetch("/api/admin/service")
      if (!response.ok) {
        throw new Error("Failed to fetch system status")
      }
      const data = await response.json()
      if (data.success) {
        setStatus(data.status)
        setError(null)
      } else {
        setError(data.error || "Failed to load system status")
      }
    } catch (err) {
      console.error("Error fetching system status:", err)
      setError("Failed to load system status. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  // Initial load and refresh interval
  useEffect(() => {
    fetchStatus()

    // Set up refresh interval (every 10 seconds)
    const interval = setInterval(fetchStatus, 10000)
    setRefreshInterval(interval as unknown as number)

    return () => {
      if (refreshInterval) {
        clearInterval(refreshInterval)
      }
    }
  }, [])

  // Execute service action
  const executeAction = async (action: string, service: string) => {
    setActionLoading(`${action}-${service}`)
    setError(null)

    try {
      const response = await fetch("/api/admin/service", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ action, service }),
      })

      const data = await response.json()
      if (data.success) {
        setStatus(data.status)
      } else {
        setError(data.error || `Failed to ${action} ${service}`)
      }
    } catch (err) {
      console.error(`Error executing ${action} on ${service}:`, err)
      setError(`Failed to ${action} ${service}. Please try again.`)
    } finally {
      setActionLoading(null)
    }
  }

  // Manual refresh
  const handleRefresh = () => {
    setLoading(true)
    fetchStatus()
  }

  // Format date
  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "Never"
    return new Date(dateStr).toLocaleString()
  }

  // Calculate uptime
  const calculateUptime = (startTimeStr: string | null) => {
    if (!startTimeStr) return "N/A"

    const startTime = new Date(startTimeStr).getTime()
    const now = Date.now()
    const uptimeMs = now - startTime

    const seconds = Math.floor(uptimeMs / 1000)
    const minutes = Math.floor(seconds / 60)
    const hours = Math.floor(minutes / 60)
    const days = Math.floor(hours / 24)

    if (days > 0) {
      return `${days}d ${hours % 24}h ${minutes % 60}m`
    } else if (hours > 0) {
      return `${hours}h ${minutes % 60}m ${seconds % 60}s`
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`
    } else {
      return `${seconds}s`
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center">
            <RefreshCw className="h-8 w-8 animate-spin text-gray-500" />
          </div>
          <p className="text-center mt-4">Loading system status...</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>System Monitor</CardTitle>
            <CardDescription>Current status of arbitrage services</CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={handleRefresh} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md flex items-start">
            <AlertTriangle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
            <div>{error}</div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Live Trading Status */}
          <div className="border rounded-lg p-4 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-medium text-lg flex items-center">
                <Terminal className="h-5 w-5 mr-2" />
                Live Trading
              </h3>
              <Badge variant={status?.live.running ? "success" : "secondary"}>
                {status?.live.running ? "Running" : "Stopped"}
              </Badge>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  Last Started:
                </div>
                <span>{formatDate(status?.live.lastStart)}</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <RefreshCw className="h-4 w-4 mr-2 text-gray-500" />
                  Last Check:
                </div>
                <span>{formatDate(status?.live.lastCheck)}</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <BarChart2 className="h-4 w-4 mr-2 text-gray-500" />
                  Uptime:
                </div>
                <span>{status?.live.running ? calculateUptime(status.live.lastStart) : "N/A"}</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <AlertTriangle className="h-4 w-4 mr-2 text-gray-500" />
                  Errors:
                </div>
                <span>{status?.live.errors.length || 0}</span>
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              {status?.live.running ? (
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => executeAction("stop", "live")}
                  disabled={actionLoading === "stop-live"}
                >
                  {actionLoading === "stop-live" ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Pause className="h-4 w-4 mr-2" />
                  )}
                  Stop
                </Button>
              ) : (
                <Button
                  size="sm"
                  onClick={() => executeAction("start", "live")}
                  disabled={actionLoading === "start-live"}
                >
                  {actionLoading === "start-live" ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Play className="h-4 w-4 mr-2" />
                  )}
                  Start
                </Button>
              )}
            </div>
          </div>

          {/* Simulation Status */}
          <div className="border rounded-lg p-4 space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-medium text-lg flex items-center">
                <BarChart2 className="h-5 w-5 mr-2" />
                Simulation
              </h3>
              <Badge variant={status?.simulation.running ? "success" : "secondary"}>
                {status?.simulation.running ? "Running" : "Stopped"}
              </Badge>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-gray-500" />
                  Last Started:
                </div>
                <span>{formatDate(status?.simulation.lastStart)}</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <RefreshCw className="h-4 w-4 mr-2 text-gray-500" />
                  Last Check:
                </div>
                <span>{formatDate(status?.simulation.lastCheck)}</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <BarChart2 className="h-4 w-4 mr-2 text-gray-500" />
                  Uptime:
                </div>
                <span>{status?.simulation.running ? calculateUptime(status.simulation.lastStart) : "N/A"}</span>
              </div>
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <AlertTriangle className="h-4 w-4 mr-2 text-gray-500" />
                  Errors:
                </div>
                <span>{status?.simulation.errors.length || 0}</span>
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              {status?.simulation.running ? (
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => executeAction("stop", "simulation")}
                  disabled={actionLoading === "stop-simulation"}
                >
                  {actionLoading === "stop-simulation" ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Pause className="h-4 w-4 mr-2" />
                  )}
                  Stop
                </Button>
              ) : (
                <Button
                  size="sm"
                  onClick={() => executeAction("start", "simulation")}
                  disabled={actionLoading === "start-simulation"}
                >
                  {actionLoading === "start-simulation" ? (
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Play className="h-4 w-4 mr-2" />
                  )}
                  Start
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button
          variant="outline"
          className="w-full"
          onClick={() => executeAction("sync", "all")}
          disabled={actionLoading === "sync-all"}
        >
          {actionLoading === "sync-all" ? (
            <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <CheckCircle className="h-4 w-4 mr-2" />
          )}
          Sync Services with Settings
        </Button>
      </CardFooter>
    </Card>
  )
}
