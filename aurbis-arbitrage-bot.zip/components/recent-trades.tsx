"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useState, useEffect } from "react"

type Trade = {
  id: string
  pair: string
  buyExchange: string
  sellExchange: string
  amount: number
  profit: number
  status: "completed" | "pending" | "failed"
  timestamp: Date
}

export function RecentTrades() {
  const [trades, setTrades] = useState<Trade[]>([])

  // Simulate new trades
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        const newTrade: Trade = {
          id: Math.random().toString(36).substring(2, 9),
          pair: ["BTC/USDT", "ETH/USDT", "SOL/USDT"][Math.floor(Math.random() * 3)],
          buyExchange: ["Binance", "Bybit", "OKX"][Math.floor(Math.random() * 3)],
          sellExchange: ["Binance", "Bybit", "OKX"][Math.floor(Math.random() * 3)],
          amount: Number.parseFloat((Math.random() * 0.5 + 0.1).toFixed(4)),
          profit: Number.parseFloat((Math.random() * 50 + 5).toFixed(2)),
          status: Math.random() > 0.9 ? "failed" : Math.random() > 0.7 ? "pending" : "completed",
          timestamp: new Date(),
        }

        // Ensure buy and sell exchanges are different
        if (newTrade.buyExchange !== newTrade.sellExchange) {
          setTrades((prev) => [newTrade, ...prev].slice(0, 5))
        }
      }
    }, 12000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Trades</CardTitle>
        <CardDescription>Executed arbitrage transactions</CardDescription>
      </CardHeader>
      <CardContent>
        {trades.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No trades executed yet.
            <p className="text-sm mt-2">Trades will appear here once executed.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {trades.map((trade) => (
              <div key={trade.id} className="border rounded-lg p-3 hover:bg-muted/50 transition-colors">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold">{trade.pair}</span>
                  <Badge
                    variant={
                      trade.status === "completed"
                        ? "default"
                        : trade.status === "pending"
                          ? "secondary"
                          : "destructive"
                    }
                  >
                    {trade.status.charAt(0).toUpperCase() + trade.status.slice(1)}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-gray-500">Buy</p>
                    <p className="font-medium">{trade.buyExchange}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Sell</p>
                    <p className="font-medium">{trade.sellExchange}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Amount</p>
                    <p className="font-medium">
                      {trade.amount} {trade.pair.split("/")[0]}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-500">Profit</p>
                    <p className={`font-medium ${trade.status === "completed" ? "text-green-500" : ""}`}>
                      ${trade.profit}
                    </p>
                  </div>
                </div>
                <div className="text-xs text-gray-400 mt-2 text-right">{trade.timestamp.toLocaleTimeString()}</div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
